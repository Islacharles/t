<?php
// Include database connection file
include '../../Config/connection.php';

// Start session to access user ID
session_start();

// Set the content type to JSON
header('Content-Type: application/json');

if (!isset($_SESSION['id'])) {
    die(json_encode(['success' => false, 'error' => 'Error: id not logged in. Please log in first.']));
}

$id = $_SESSION['id'];

// Check if the form is submitted via POST method
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Sanitize and retrieve the data from the POST request
    $fullname = htmlspecialchars(trim($_POST['new_fullname']));
    $contact_number = htmlspecialchars(trim($_POST['new_contact_number']));
    $email = htmlspecialchars(trim($_POST['new_email']));
    $address = htmlspecialchars(trim($_POST['new_address']));

    // Prepare the SQL query to update the user's information
    $sql = "UPDATE admin_staff SET fullname = ?, contact_number = ?, email = ?, address = ? WHERE id = ?";

    // Prepare and execute the SQL query
    if ($stmt = $conn->prepare($sql)) {
        // Bind the parameters to the query
        $stmt->bind_param("ssssi", $fullname, $contact_number, $email, $address, $id);

        // Execute the query
        if ($stmt->execute()) {
            // If the update is successful, return a success response
            echo json_encode(['success' => true, 'message' => 'Account information updated successfully']);
        } else {
            // If there is an error executing the query, return the error
            echo json_encode(['success' => false, 'error' => 'Error updating record: ' . $stmt->error]);
        }

        // Close the prepared statement
        $stmt->close();
    } else {
        // If the query preparation fails, return the error
        echo json_encode(['success' => false, 'error' => 'Error preparing statement: ' . $conn->error]);
    }

    // Close the database connection
    $conn->close();
} else {
    // If the request method is not POST, return an error
    echo json_encode(['success' => false, 'error' => 'Invalid request method']);
    exit();
}
?>
