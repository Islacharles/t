<?php
session_start();
include '../../Config/connection.php';

header('Content-Type: application/json');
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Debug session
if (!isset($_SESSION['admin_id'])) {
    echo json_encode([
        "error" => "Session expired. Please log in again.",
        "session_data" => $_SESSION // Debugging
    ]);
    exit;
}
// Debug form data
if (empty($_POST['title']) || empty($_POST['description'])) {
    echo json_encode(["error" => "Title and Description are required."]);
    exit;
}

$title = trim($_POST['title']);
$description = trim($_POST['description']);
$admin_id = $_SESSION['admin_id'];

$sql = "INSERT INTO announcements (title, description, added_by) VALUES (?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ssi", $title, $description, $admin_id);

if ($stmt->execute()) {
    echo json_encode(["message" => "Announcement Successfully Added"]);
} else {
    echo json_encode(["error" => "Database error: " . $stmt->error]);
}
?>
