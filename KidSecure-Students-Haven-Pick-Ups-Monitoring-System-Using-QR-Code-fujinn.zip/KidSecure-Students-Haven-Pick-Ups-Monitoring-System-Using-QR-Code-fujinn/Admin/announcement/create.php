<?php 
session_start();
include '../../Config/connection.php';
$_SESSION['header'] = 'Create Announcement';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <link href="index.css" rel="stylesheet" />
</head>
<body>

<?php include '../shared/sidebar.php'; ?>

<div class="main-content">
    <h2>Create Announcement</h2>

    <form id="announcementForm">
        <label>Title:</label>
        <input type="text" id="title" required>
        <label>Description:</label>
        <input type="text" id="description" required>
        <button type="submit" class="btn btn-success">Submit</button>
    </form>

    <a href="index.php" class="btn btn-secondary">Back</a>

</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<script>
    $(document).ready(function () {
        $('#announcementForm').on('submit', function (e) {
            e.preventDefault();

            var title = $('#title').val();
            var description = $('#description').val();

            if (title && description) {
                $.ajax({
                    url: 'create-api.php',
                    type: 'POST',
                    data: { title: title, description: description },
                    success: function (response) {
                        alert(response?.message || 'Announcement added successfully.');
                        window.location.href = 'index.php'; 
                    }
                });
            }
        });
    });
</script>

</body>
</html>
