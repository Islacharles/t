<?php
include '../../Config/connection.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = isset($_POST['ID']) ? $_POST['ID'] : null;

    if (!$id) {
        echo json_encode(["message" => "Invalid ID"]);
        exit;
    }

    // Prepare DELETE SQL statement
    $sql = "DELETE FROM announcements WHERE ID = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);

    // Execute the query and return response
    if ($stmt->execute()) {
        echo json_encode(["message" => "Announcement archived successfully!"]);
    } else {
        echo json_encode(["message" => "Error deleting announcement."]);
    }

    // Close the statement
    $stmt->close();
    $conn->close();
}
?>
