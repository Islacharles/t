<?php
session_start();
include '../../Config/connection.php';

// Ensure JSON response
header('Content-Type: application/json');

// Prevent PHP warnings/errors from breaking JSON
error_reporting(0);
ini_set('display_errors', 0);

$sql = "SELECT a.id, a.title, a.description, a.created_at, u.fullname AS admin_name 
        FROM announcements a 
        JOIN admin_staff u ON a.added_by = u.id 
        ORDER BY a.created_at DESC";

$result = $conn->query($sql);

if (!$result) {
    echo json_encode(["error" => "Query failed: " . $conn->error]);
    exit;
}

$data = [];
while ($row = $result->fetch_assoc()) {
    $data[] = [
        "ID" => $row['id'],
        "TITLE" => $row['title'],
        "DESCRIPTION" => $row['description'],
        "CREATED_AT" => date("F j, Y, g:i A", strtotime($row['created_at'])), // Format date
        "ADMIN_NAME" => $row['admin_name']
    ];
}

// Clean output buffer to avoid extra characters
ob_clean();
echo json_encode($data);
?>
