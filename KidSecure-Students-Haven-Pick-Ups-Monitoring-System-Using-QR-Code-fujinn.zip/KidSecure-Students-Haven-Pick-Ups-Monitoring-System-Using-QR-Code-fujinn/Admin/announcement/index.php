<?php 
session_start();
$_SESSION['admin_id'] = 1;
include '../../Config/connection.php'; 
include '../../Config/jslib.php';
$_SESSION['header'] = 'Announcement';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <link href="index.css" rel="stylesheet" />
</head>

<body>

<?php include '../shared/sidebar.php'; ?>

<div class="container-main">
    <div class="main-wrapper-body">
    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#createModal" style="margin-bottom: 15px;">Create Announcement</button>
    <table id="announcementTable" class="display table table-bordered">
        <thead class="table-dark">
            <tr>
                <th>Title</th>
                <th>Description</th>
                <th>Created By</th>
                <th>Date Created</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
        </tbody>
    </table>
</div>

<div class="modal fade" id="createModal" tabindex="-1" aria-labelledby="createModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="createModalLabel">Create Announcement</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
            <form id="announcementForm">
                <div class="mb-3">
                    <label for="title" class="form-label">Title</label>
                    <input type="text" class="form-control" id="title" name="title" required>
                </div>
                <div class="mb-3">
                    <label for="description" class="form-label">Description</label>
                    <textarea class="form-control" id="description" name="description" rows="3" required></textarea>
                </div>
                <button type="submit" class="btn btn-success">Save</button>
            </form>

            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function () {
    var table = $('#announcementTable').DataTable({
        dom: '<"row"<"col-md-6"l><"col-md-6 text-end"Bf>>rtip',
        buttons: ['copy', 'csv', 'excel', 'pdf', 'print'],
        ajax: {
            url: 'index-search-api.php',
            type: 'GET',
            dataSrc: ''
        },
        columns: [
            { data: 'TITLE' },
            { data: 'DESCRIPTION' },
            { data: 'ADMIN_NAME' },
            { data: 'CREATED_AT' },
            {
                data: 'ID',
                render: function (data) {
                    return `<button class='btn btn-danger btn-sm deleteBtn' data-id='${data}'>Archive</button>`;
                }
            }
        ]
    });

    $('#announcementForm').submit(function (e) {
    e.preventDefault();

    let formData = $(this).serialize();
    console.log("Submitting Form Data:", formData); // Debugging

    $.ajax({
        url: 'create-api.php',
        type: 'POST',
        data: formData,
        success: function (response) {
            console.log("Response Received:", response); // Debugging
            if (response.error) {
                alert(response.error);
            } else {
                alert(response.message);
                $('#announcementForm')[0].reset();
                $('#createModal').modal('hide');
                $('#announcementTable').DataTable().ajax.reload(null, false);
            }
        },
        error: function (xhr) {
            console.log("AJAX Error:", xhr.responseText); // Debugging
            alert('An error occurred: ' + xhr.responseText);
        }
    });
});

    $('#announcementTable').on('click', '.deleteBtn', function () {
        const announcementId = $(this).data('id');
        if (confirm('Are you sure you want to archive this announcement?')) {
            $.ajax({
                url: 'delete-api.php',
                type: 'POST',
                data: { ID: announcementId },
                success: function (response) {
                    alert(response?.message || 'Announcement archived successfully.');
                    table.ajax.reload(null, false);
                },
                error: function (xhr) {
                    console.log(xhr.responseText);
                    alert('An error occurred while archiving the announcement.');
                }
            });
        }
    });
});

</script>

</body>
</html>
