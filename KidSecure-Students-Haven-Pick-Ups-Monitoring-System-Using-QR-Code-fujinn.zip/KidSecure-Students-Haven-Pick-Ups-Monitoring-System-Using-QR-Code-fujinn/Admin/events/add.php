<?php
include '../../Config/connection.php';

// Decode incoming JSON data
$data = json_decode(file_get_contents("php://input"), true);

// Extract the variables from the JSON data
$title = $data['title'];
$image = $data['image'];
$description = $data['description'];
$date = date('Y-m-d'); // Set the current date as the event date, or you can modify this if you need a custom date

// Prepare the SQL query with placeholders for binding parameters
$sql = "INSERT INTO events (TITLE, IMAGE, DESCRIPTION, DATE) VALUES (?, ?, ?, ?)";
$stmt = $conn->prepare($sql);

// Bind the parameters to the placeholders: 'sss' means 3 strings, and 's' is for date type (string in the SQL query)
$stmt->bind_param("ssss", $title, $image, $description, $date);

// Execute the query and check the result
if ($stmt->execute()) {
    echo json_encode(["message" => "Event added successfully!"]);
} else {
    echo json_encode(["message" => "Failed to add event."]);
}

// Close the statement
$stmt->close();
?>
