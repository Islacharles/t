<?php
include '../../Config/connection.php';

$data = json_decode(file_get_contents("php://input"), true);
$id = $data['id'];

$sql = "UPDATE events SET `STATUS` = b'0'  WHERE ID = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);

if ($stmt->execute()) {
    echo json_encode(["message" => "Events Archived successfully!"]);
} else {
    echo json_encode(["message" => "Failed to delete blog."]);
}
?>
