<?php
require '../../vendor/autoload.php'; // Include PhpSpreadsheet

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\Style\Font;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\Fill;

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    try {
        // Create a new Spreadsheet
        $spreadsheet = new Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();

        // Set the title for the spreadsheet
        $sheet->setCellValue('A1', 'EVENT RECORDS');
        $sheet->mergeCells('A1:C1'); // Merge cells for the title
        $sheet->getStyle('A1')->getFont()->setBold(true)->setSize(16);
        $sheet->getStyle('A1')->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);

        // Apply header styling with blue background
        $sheet->setCellValue('A2', 'Title');
        $sheet->setCellValue('B2', 'Description');
        $sheet->setCellValue('C2', 'Date');

        $headerStyle = [
            'font' => [
                'bold' => true,
                'color' => ['argb' => 'FFFFFF'],
                'size' => 12
            ],
            'alignment' => [
                'horizontal' => Alignment::HORIZONTAL_CENTER,
                'vertical' => Alignment::VERTICAL_CENTER,
            ],
            'fill' => [
                'fillType' => Fill::FILL_SOLID,
                'startColor' => ['argb' => '0000FF'], // Blue background
            ],
        ];
        $sheet->getStyle('A2:C2')->applyFromArray($headerStyle);

        // Fetch events from the database
        include '../../Config/connection.php';
        $query = "SELECT title, description, date FROM events";
        $result = $conn->query($query);

        if ($result->num_rows > 0) {
            $row = 3; // Start from the third row (below the header)
            while ($event = $result->fetch_assoc()) {
                $description = (strlen($event['description']) > 30) ? substr($event['description'], 0, 30) . '...' : $event['description']; // Truncate description
                $sheet->setCellValue("A$row", $event['title']);
                $sheet->setCellValue("B$row", $description);
                $sheet->setCellValue("C$row", $event['date']);
                $row++;
            }

            // Apply data styling
            $dataStyle = [
                'alignment' => [
                    'horizontal' => Alignment::HORIZONTAL_LEFT,
                    'vertical' => Alignment::VERTICAL_CENTER,
                    'wrapText' => true, // Wrap text within the cell
                ],
            ];
            $sheet->getStyle('A3:C' . ($row - 1))->applyFromArray($dataStyle);
        }

        // Set fixed width for the Description column and auto-resize for others
        $sheet->getColumnDimension('B')->setWidth(30); // Fixed width for 'Description' column
        foreach (range('A', 'C') as $columnID) {
            if ($columnID !== 'B') { // Auto-resize for all columns except 'B'
                $sheet->getColumnDimension($columnID)->setAutoSize(true);
            }
        }

        // Set the file name
        $fileName = 'events_list_report.xlsx';

        // Output to the browser
        header("Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        header("Content-Disposition: attachment; filename=\"$fileName\"");
        header("Cache-Control: max-age=0");

        // Save the file to output
        $writer = new Xlsx($spreadsheet);
        $writer->save('php://output');
        exit;

    } catch (Exception $e) {
        echo 'Error: ' . $e->getMessage();
        exit;
    }
}
?>
