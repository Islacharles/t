<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

include '../../Config/connection.php';

$sql = "SELECT * FROM events WHERE STATUS = b'0'";
$result = $conn->query($sql);

if ($result === false) {
    // Output SQL error if the query fails
    echo json_encode(['error' => 'SQL query failed']);
    exit;
}

$blogs = [];
while ($row = $result->fetch_assoc()) {
    $blogs[] = [
        'id' => $row['ID'],
        'title' => $row['TITLE'],
        'image' => $row['IMAGE'],
        'description' => $row['DESCRIPTION'],
        'date' => $row['date']  // Make sure the field exists in your table
    ];
}

echo json_encode($blogs);
?>
