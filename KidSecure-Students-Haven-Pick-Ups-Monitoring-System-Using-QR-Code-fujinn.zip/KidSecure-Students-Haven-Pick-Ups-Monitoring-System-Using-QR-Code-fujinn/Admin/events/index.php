<?php
session_start(); // Start the session
include '../../Config/connection.php'; 
$_SESSION['header'] = 'Event Management';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Event Blog</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.10.5/font/bootstrap-icons.min.css" rel="stylesheet">
    <link href="index.css" rel="stylesheet"/>
    <link rel="stylesheet" href="dataTables.min.css">
</head>
<body>
<?php include '../shared/sidebar.php'; ?>
<div class="main-content">
    <div class="container">
        <!-- Add Event Buttons -->
        <div class="d-flex justify-content-between mb-2">
    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addBlogModal">
        <i class="bi bi-plus"></i> Add Event
    </button>
    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#eventListModal">
        <i class="bi bi-list"></i> All Events
    </button>
</div>
<div class="d-flex justify-content-between mb-2">
    <div class="d-flex justify-content-start">
        <!-- All Events Button -->
        
    </div>
    <!-- Export Button Positioned to the Right -->
    <div class="d-flex justify-content-end ms-auto">
        <!-- <button id="exportToExcelBtn" class="btn btn-success">
            <i class="bi bi-file-earmark-excel"></i> Generate Events Report
        </button> -->
        <button type="button" class="btn btn-danger" style="margin-left: 10px;" id="viewArchived" data-bs-toggle="modal" data-bs-target="#archivedModal"> View Archived Events </button>
    </div>
</div>


        <!-- Event Carousel -->
        <div id="eventCarousel" class="carousel slide" data-bs-ride="carousel">
            <div class="carousel-inner" id="blogContainer">
                <!-- Dynamic content will be inserted here -->
            </div>
            <button class="carousel-control-prev" type="button" data-bs-target="#eventCarousel" data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#eventCarousel" data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
            </button>
        </div>
    </div>
</div>

<!-- All Events Modal -->
<div class="modal fade" id="eventListModal" tabindex="-1" aria-labelledby="eventListModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="eventListModalLabel">All Events</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            
            <div class="modal-body">
                <table id="EventTable" class="table table-striped table-bordered display nowrap" style="width:100%">
                    <thead>
                        <tr>
                            <th>Title</th>
                            <th>Description</th>
                            <th>Date</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <!-- Populated dynamically by DataTable -->
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Add/Edit Blog Modals -->
<!-- Add Blog Modal -->
<div class="modal fade" id="addBlogModal" tabindex="-1" aria-labelledby="addBlogModalLabel" aria-hidden="true">
    <div class="modal-dialog d-flex justify-content-center align-items-center">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addBlogModalLabel">Add Blog</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form id="addBlogForm">
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="blogTitle" class="form-label">Title</label>
                        <input type="text" class="form-control" id="blogTitle" required>
                    </div>
                    <div class="mb-3">
                        <label for="blogDescription" class="form-label">Description</label>
                        <textarea class="form-control" rows="8" id="blogDescription" required></textarea>
                    </div>
                    <div class="mb-3">
                        <label for="blogImage" class="form-label">Image</label>
                        <input type="file" class="form-control" id="blogImage" accept="image/*" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary">Post</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Edit Blog Modal -->
<div class="modal fade" id="editBlogModal" tabindex="-1" aria-labelledby="editBlogModalLabel" aria-hidden="true">
    <div class="modal-dialog d-flex justify-content-center align-items-center">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editBlogModalLabel">Edit Blog</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form id="editBlogForm">
                <div class="modal-body">
                    <input type="hidden" id="editBlogId">
                    <div class="mb-3">
                        <label for="editBlogTitle" class="form-label">Title</label>
                        <input type="text" class="form-control" id="editBlogTitle" required>
                    </div>
                    <div class="mb-3">
                        <label for="editBlogDescription" class="form-label">Description</label>
                        <textarea class="form-control" rows="4" id="editBlogDescription" required></textarea>
                    </div>
                    <div class="mb-3">
                        <label for="editBlogImage" class="form-label">Image</label>
                        <input type="file" class="form-control" id="editBlogImage" accept="image/*">
                        <img id="editBlogImagePreview" class="img-fluid mb-2" style="display:none;">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" id="backToEventList">Back</button>
                    <button type="submit" class="btn btn-primary">Update</button>
                </div>
            </form>
        </div>
    </div>
</div>

    <!-- Archived Students Modal -->
    <div class="modal fade" id="archivedModal" tabindex="-1" aria-labelledby="archivedModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="archivedModalLabel">Archived Students</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <table class="table table-bordered table-hover align-middle" id="ArchivedTable">
                    <thead class="table-dark">
                        <tr>
                            <th>Picture</th>
                            <th>Title</th>
                            <th>Description</th>
                            <th>Date</th>
                    </thead>
                    <tbody></tbody>
                </table>
            </div>
        </div>
    </div>
</div>



<script>
    const API_BASE_URL = ""; // Set your API base URL

    // Initialize DataTable in modal when opened
    $('#eventListModal').on('shown.bs.modal', function () {
        if (!$.fn.DataTable.isDataTable('#EventTable')) {
            $('#EventTable').DataTable({
            dom: '<"row"<"col-md-6"l><"col-md-6 text-end"Bf>>rtip',  // This defines the layout for DataTable buttons
            buttons: ['copy', 'csv', 'excel', 'pdf', 'print'],
    ajax: {
        url: `${API_BASE_URL}get.php`, // API to fetch all events
        type: 'GET',
        dataSrc: ''
    },
    columns: [
    { data: 'title' },
    {
        data: 'description',
        render: function (data, type, row) {
            // Truncate description to a maximum length (e.g., 50 characters)
            const maxLength = 50;
            const truncatedDescription =
                data.length > maxLength
                    ? data.substring(0, maxLength) + '...'
                    : data;
            return `<div class="truncate" title="${data}">${truncatedDescription}</div>`;
        }
    },
    {
        data: 'date',
        render: function (data) {
            if (data) {
                const dateObj = new Date(data);
                const yyyy = dateObj.getFullYear();
                let mm = dateObj.getMonth() + 1;
                let dd = dateObj.getDate();

                if (mm < 10) mm = '0' + mm;
                if (dd < 10) dd = '0' + dd;

                return `${yyyy}-${mm}-${dd}`; // Return the formatted date
            }
            return data; // If no date, return as is
        }
    },
    {
        data: 'id',
        render: function (data, type, row) {
                return `
                    <button class="btn btn-info btn-sm btnEdit" style="color: white;" 
                            data-id="${row.id}" 
                            data-title="${row.title}" 
                            data-image="${row.image}" 
                            data-description="${row.description}">
                        Edit
                    </button>
                    <button class="btn btn-danger btn-sm btnarchive" data-id="${row.id}">archive</button>
                `;
            }

    }
],

    destroy: true, // Allow reinitialization
});

        }
    });

    $('#EventTable').on('click', '.btnEdit', function () {
    const id = $(this).data('id');
    const title = $(this).data('title');
    const image = $(this).data('image');
    const description = $(this).data('description');

    // Call the editBlog function
    editBlog(id, title, image, description);
});

    // archive Event
    $('#EventTable').on('click', '.btnarchive', function () {
    const id = $(this).data('id');
    if (confirm('Are you sure you want to archive this event?')) {
        $.post(`${API_BASE_URL}delete.php`, JSON.stringify({ id }))
            .done(function () {
                alert('Event Archived Successfully!');
                
                // Remove the event from the carousel
                $(`#carouselItem-${id}`).remove();  // Remove the carousel item
                
                // Check if there are any items left in the carousel
                const remainingItems = $('#blogContainer .carousel-item').length;
                
                if (remainingItems === 0) {
                    $('#eventCarousel').hide();  // Hide the carousel if no items are left
                } else {
                    // Trigger carousel to go to the next available item
                    const activeItem = $('#blogContainer .carousel-item.active');
                    if (!activeItem.length) {
                        // If no active item, activate the first item
                        $('#blogContainer .carousel-item').first().addClass('active');
                    }
                    // Trigger the carousel to update and display the next or first item
                    $('#eventCarousel').carousel('next');
                }

                // Reload DataTable (it will also reflect the updated data)
                $('#EventTable').DataTable().ajax.reload();
                
                // Re-fetch and update the carousel with the latest events
                fetchBlogs();  // Re-fetch the events and refresh the carousel
            })
            .fail(function () {
                alert('Failed to archive event. Please check the server.');
            });
    }
});


    
    // Add Event
  // Add Event
$('#addBlogForm').on('submit', function (e) {
    e.preventDefault();
    const title = $('#blogTitle').val();
    const desc = $('#blogDescription').val();
    const file = $('#blogImage')[0].files[0];

    if (!file) {
        alert('Please select an image.');
        return;
    }

    const reader = new FileReader();
    reader.onload = function () {
        $.post(
            `${API_BASE_URL}add.php`,
            JSON.stringify({ title, image: reader.result, description: desc })
        )
        .done(function () {
            alert('Event Added Successfully!');

            // Close the modal and reset the form
            $('#addBlogModal').modal('hide');
            $('body').removeClass('modal-open');
            $('.modal-backdrop').remove(); // Remove the backdrop
            $('#addBlogForm')[0].reset(); // Reset the form fields

            // Reload both the carousel and the event list
            fetchBlogs(); // Refresh the carousel with updated events
            $('#EventTable').DataTable().ajax.reload(); // Reload the DataTable
        })
        .fail(function () {
            alert('Failed to add event. Please check the server.');
        });
    };
    reader.readAsDataURL(file);
});


function editBlog(id, title, image, description) {
    // Set form values with the parameters passed to the function
    $('#editBlogId').val(id);
    $('#editBlogTitle').val(title);  // Populate the title
    $('#editBlogDescription').val(description);  // Populate the description

    if (image) {
        // If an image is available, show the preview image
        $('#editBlogImagePreview').attr('src', image).show();
    } else {
        $('#editBlogImagePreview').hide();  // If no image, hide the preview
    }

    // Hide the event list modal and show the edit modal
    $('#eventListModal').modal('hide');
    $('#editBlogModal').modal('show');
}

// Update Blog
$('#editBlogForm').on('submit', function (e) {
    e.preventDefault();
    const id = $('#editBlogId').val();
    const title = $('#editBlogTitle').val();
    const description = $('#editBlogDescription').val();
    const file = $('#editBlogImage')[0].files[0];

    if (file) {
        const reader = new FileReader();
        reader.onload = function () {
            updateBlog(id, title, reader.result, description);
        };
        reader.readAsDataURL(file);
    } else {
        const currentImage = $('#editBlogImagePreview').attr('src');
        updateBlog(id, title, currentImage, description);
    }
});

// Update blog event handler
function updateBlog(id, title, image, description) {
    $.post(
        `${API_BASE_URL}edit.php`,
        JSON.stringify({ id, title, image, description })
    )
    .done(function () {
        alert('Event Updated Successfully!');
        $('#editBlogModal').modal('hide');
        
        // Reload DataTable to reflect the updated event
        $('#EventTable').DataTable().ajax.reload();  

        // Re-fetch and update the carousel with the latest events
        fetchBlogs();  // Re-fetch the events and refresh the carousel
    })
    .fail(function () {
        alert('Failed to update event. Please check the server.');
    });
}


    // Fetch Blogs
    // Fetch Blogs
function fetchBlogs() {
    $.get(`${API_BASE_URL}get.php`)
        .done(function (data) {
            const blogs = JSON.parse(data);
            let blogHTML = '';
            blogs.forEach((blog, index) => {
                blogHTML += `
                    <div class="carousel-item ${index === 0 ? 'active' : ''}" id="carouselItem-${blog.id}">
                        <img src="${blog.image}" alt="${blog.title}" class="d-block w-100">
                        <div class="overlay">
                            <div class="title">${blog.title}</div>
                            <div class="description">${blog.description ?? ''}</div>
                        </div>
                    </div>
                `;
            });
            $('#blogContainer').html(blogHTML);  // Update the carousel content

            // Reinitialize the carousel to make sure it picks up the newly inserted items
            $('#eventCarousel').carousel('next'); // Optional: You can directly navigate to the newly added item
        })
        .fail(function () {
            alert('Failed to fetch events. Please check the server.');
        });
}


// Back button: Transition smoothly between modals
$('#backToEventList').on('click', function () {
    $('#editBlogModal').modal('hide'); // Hide the Edit Blog Modal

    // Ensure the backdrop remains visible during the transition
    setTimeout(() => {
        $('#eventListModal').modal('show'); // Show the Event List Modal
    }, 300); // Add a slight delay for smooth transition
});

// Add this to prevent removing the backdrop unnecessarily
$('#editBlogModal').on('hidden.bs.modal', function (e) {
    if ($('#eventListModal').hasClass('show')) {
        // Prevent backdrop removal if Event List Modal is already open
        e.stopPropagation();
    } else {
        resetModalState(); // Ensure proper state otherwise
    }
});


    fetchBlogs(); // Fetch blogs on page load

    function resetModalState() {
    if (!$('.modal.show').length) {
        $('body').removeClass('modal-open');
        $('.modal-backdrop').remove();
    }
}
$('#exportToExcelBtn').on('click', function () {
    window.open(`${API_BASE_URL}export_to_excel.php`, '_blank');
});
            $(document).ready(function () {
                const archivedTable = $('#ArchivedTable').DataTable({
                    ajax: {
                        url: 'fetch-archived-events-api.php',
                        type: 'GET',
                        dataSrc: ''
                    },
                    columns: [
                        {
                        data: 'image',
                        render: function (data) {
                            return `<img src="data:image/png;base64,${data}" class="table-img" alt="N/A">`;
                        }
                        },
                        { data: 'title' },
                        { data: 'description' },
                        { data: 'date' }
                    ]
                });
            });
</script>
</body>
</html>
