<?php
include '../../Config/api-config.php';  // Database configuration
include '../../Config/connection.php'; // Open connection
include '../../Config/encryption.php'; // Encryption functions

// Get data from POST request
$parentId = $_POST['parent_id'] ?? '';
$defaultPword = $_POST['defaultpw'] ?? '';

// Validate required fields
if (empty($parentId) || empty($defaultPword)) {
    echo json_encode(['error' => 'Parent ID and new password are required']);
    exit();
}

// Encrypt the password
$encryptedPword = encrypt($defaultPword);

// SQL query to update the password
$updateSql = "UPDATE guardian SET PASSWORD = ? WHERE ID = ?";
$updateStmt = $conn->prepare($updateSql);

// Bind parameters (s for string)
$updateStmt->bind_param("ss", $encryptedPword, $parentId);

// Execute the update
if ($updateStmt->execute()) {
    $response = array(
        'status' => 'success',
        'message' => 'Password reset successfully!'
    );
} else {
    $response = array(
        'status' => 'error',
        'message' => 'Failed to update password: ' . $updateStmt->error
    );
}

// Send the response as JSON
echo json_encode($response);

// Close the statements and connection
$updateStmt->close();
$conn->close();
?>
