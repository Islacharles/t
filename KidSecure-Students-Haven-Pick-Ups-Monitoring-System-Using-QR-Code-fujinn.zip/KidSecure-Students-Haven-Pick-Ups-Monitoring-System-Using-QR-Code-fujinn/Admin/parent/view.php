<?php
session_start(); // Start the session
include '../../Config/connection.php';

if(!isset($_GET['id'])){
    header("Location: index.php");
}

$parentId = $_GET['id'] ;

// SQL Query to select all data using JOINs
$sql = "SELECT
        g.ID AS parent_number,
        g.FIRSTNAME AS guardian_first_name, 
        g.LASTNAME AS guardian_last_name, 
        g.MIDDLENAME AS guardian_middle_name, 
        g.CONTACT_NUMBER AS guardian_contact, 
        g.ADDRESS AS guardian_address, 
        g.PICTURE AS guardian_picture, 
        g.EMAIL AS guardian_email,
        s.ID AS student_number, 
        s.FIRSTNAME AS student_first_name, 
        s.LASTNAME AS student_last_name, 
        s.MIDDLENAME AS student_middle_name, 
        s.ADDRESS AS student_address, 
        s.BIRTHDATE AS student_birthdate, 
        s.PICTURE AS student_picture, 
        s.GRADE_LEVEL AS student_grade_level, 
        s.SECTION AS student_section
    FROM guardian g
    INNER JOIN student_guardian sg ON g.ID = sg.PARENT_ID 
    INNER JOIN students s ON sg.STUDENT_NUMBER = s.ID 
    WHERE g.ID = ?
    LIMIT 1";

$stmt = $conn->prepare($sql);

// Bind parameter (s for string) to the prepared statement
$stmt->bind_param("s", $parentId);  // Bind the parameter as a string

// Execute the query
$stmt->execute();

// Get the result
$result = $stmt->get_result();

// Check if the query was successful and if there is at least one row
if ($result->num_rows > 0) {
    // Fetch the first (and only) row
    $firstRow = $result->fetch_assoc(); // Fetch the first row
 
} else {
    header("Location: index.php");
    // No data found
    echo json_encode(['message' => 'No students found']);
}

$_SESSION['header'] = 'Parent Details';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Student</title>

    <link href="view.css" rel="stylesheet"/>
</head>
<body>
    <?php include '../shared/sidebar.php' ?>
    <style>
        
        .card-container{
            width: calc(100% - 16px);
        }

        .main-header{
            width: calc(100vw - 250px) !important;
        }

        body{
            overflow-x: hidden;
        }
    </style>
    <div class="container-main">
        <div class="main-wrapper-body card-container">
            <hr>
            <div class="row">
                <div class="col-2">
                    <img src="data:image/png;base64,<?=$firstRow['guardian_picture']?>" alt="" class="user-img" id="imgGuardianUser">
                </div>
                <div class="col-10">
                    <div class="form-group">
                        <label for="txtGuardianFirstName">First Name</label>
                        <input type="text" class="form-control" id="txtGuardianFirstName" name="frmGroup" value="<?=$firstRow['guardian_first_name']?>" aria-describedby="txtName" placeholder="Enter First Name">
                        <small ident="GuardianFirstName" name="frmGroup" class="form-text text-danger"></small>
                    </div>
                    <div class="form-group">
                        <label for="txtGuardianMiddleName">Middle Name</label>
                        <input type="text" class="form-control" name="frmGroup" id="txtGuardianMiddleName" value="<?=$firstRow['guardian_middle_name']?>" aria-describedby="txtName" placeholder="Enter First Name">
                        <small ident="GuardianMiddleName" name="frmGroup" class="form-text text-danger"></small>
                    </div>
                    <div class="form-group">
                        <label for="txtGuardianLastName">Last Name</label>
                        <input type="text" class="form-control" id="txtGuardianLastName" name="frmGroup" value="<?=$firstRow['guardian_last_name']?>" aria-describedby="txtName" placeholder="Enter First Name">
                        <small  ident="GuardianLastName" name="frmGroup" class="form-text text-danger"></small>
                    </div>
                    <div class="form-group">
                        <label for="txtGuardianContactNumber">Contact Number</label>
                        <input type="number" class="form-control" id="txtGuardianContactNumber" name="frmGroup" value="<?=$firstRow['guardian_contact']?>" aria-describedby="txtName" placeholder="Enter First Name">
                        <small  ident="GuardianContactNumber" name="frmGroup" class="form-text text-danger"></small>
                    </div>
                    <div class="form-group">
                        <label for="txtGuardianAddress">Address</label>
                        <textarea id="txtGuardianAddress" class="form-control" name="frmGroup" row="3"><?=$firstRow['guardian_address']?></textarea>
                        <small ident="GuardianAddress" name="frmGroup" class="form-text text-danger"></small>
                    </div>
                    <div class="form-group">
                        <label for="txtGuardianEmail">Email</label>
                        <input type="Email" class="form-control" id="txtGuardianEmail" name="frmGroup" value="<?=$firstRow['guardian_email']?>" aria-describedby="txtName" placeholder="Enter First Name">
                        <small  ident="GuardianEmail" name="frmGroup" class="form-text text-danger"></small>
                    </div>
                    <br>
                    <hr>
                </div>
            </div>
        </div>
        <div class="main-wrapper-body card-container" style="margin-top:16px;">
            <h3>Student Details</h3>
            <hr>
            <div class="row">
                <div class="col-12 row" id="student-content">
                    
                </div>
                <div style="display:flex;justify-content: end;align-items:end;width:100%;">
                <a class="btn btn-primary" type="button" href="index.php" id="btnCancel" style="margin-right:12px;width:160px;">Back</a>
                </div>
            </div>
        </div>
    </div>
</body>
<script>
    $(document).ready(function(){
        $("input[name='frmGroup']").attr("disabled", true);
        $("select[name='frmGroup']").attr("disabled", true);
        $("textarea[name='frmGroup']").attr("disabled", true);
        $("small[name='frmGroup']").html("");
 
        searchData();
    });
    $("#btnCancel").on('click', function(){
        windows.location.href = "index.php"
    })
    
    function searchData(){
        $("#student-content").html('');
            // Make the AJAX GET request with parameters
        $.ajax({
            url: 'get-parent-student-api.php',  // Replace with your PHP script file
            type: 'GET',
            data: { search: '', guardianId : "<?=$parentId?>" },  // Send parameters in the query string
            success: function(response) {
                // Handle the response (e.g., display in a div)
                console.log(response);
                response?.forEach(obj => {
                    $("#student-content").append(` 
                        <div class="col-lg-3 col-md-4 col-sm-6">
                            <div class="card-body">
                                <img src="data:image/png;base64,${obj.picture}" alt="">
                                <div class="details">
                                    <p>${obj.student_name}</p>
                                    <small>${obj.grade_level}</small>
                                </div>
                                <div class="action">
                                    <a type="button" href="../student/view.php?id=${obj.student_number}" ident="${obj.student_number}" class="btn btn-primary">View</a>
                                </div>
                            </div>
                        </div> 
                    `)
                });
            },
            error: function(xhr, status, error) {
                // Handle error
                console.log("An error occurred: " + error);
            }
        });
    }
</script>

</html>
<?php
// Close the connection
$conn->close();
?>
