-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 25, 2025 at 04:46 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kidsecdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_staff`
--

CREATE TABLE `admin_staff` (
  `id` int(11) NOT NULL,
  `fullname` varchar(255) NOT NULL,
  `contact_number` varchar(50) NOT NULL,
  `email` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `role` varchar(255) NOT NULL,
  `profile_image` longblob NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin_staff`
--

INSERT INTO `admin_staff` (`id`, `fullname`, `contact_number`, `email`, `address`, `role`, `profile_image`, `password`) VALUES
(1, 'Students Haven', '09368919566', 'studentshaven2021@gmail.com', '66 Dona Margarita Subd. Binakayan, Kawit, Cavite', 'Super Admin', '', 'aDfjLmnDT2rLrlsFJ9sDWisxeHlTVkVKT3BZZFpzVEp4THRiRUE9PQ==');

-- --------------------------------------------------------

--
-- Table structure for table `authorize_person`
--

CREATE TABLE `authorize_person` (
  `ID` int(11) NOT NULL,
  `FIRSTNAME` varchar(80) NOT NULL,
  `MIDDLENAME` varchar(80) DEFAULT NULL,
  `LASTNAME` varchar(80) NOT NULL,
  `CONTACT_NUMBER` varchar(50) DEFAULT NULL,
  `ADDRESS` text DEFAULT NULL,
  `PARENT_ID` int(11) NOT NULL,
  `PICTURE` longtext DEFAULT NULL,
  `STATUS` bit(1) NOT NULL DEFAULT b'1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `ID` int(11) NOT NULL,
  `TITLE` varchar(244) DEFAULT NULL,
  `IMAGE` longtext DEFAULT NULL,
  `DESCRIPTION` text DEFAULT NULL,
  `date` date DEFAULT curdate(),
  `STATUS` bit(1) NOT NULL DEFAULT b'1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `forgot_password`
--

CREATE TABLE `forgot_password` (
  `USER_ID` varchar(255) NOT NULL,
  `TOKEN` varchar(255) NOT NULL,
  `EXPIRATION` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `forgot_password`
--

INSERT INTO `forgot_password` (`USER_ID`, `TOKEN`, `EXPIRATION`) VALUES
('1', '1', '2025-01-25 14:40:36'),
('10', 'ba494db3a3e52f10bfd1d1471aee4b5c', '2025-01-25 15:59:02'),
('17', '941469e7d23b14f8f7f10762d33784c5', '2025-01-25 15:59:35'),
('17', '15d8b2f1fae0ef9db01445f22cd278a5', '2025-01-25 16:00:25'),
('17', 'e5a41c01bdefca619fd56c906f036588', '2025-01-25 16:02:06'),
('17', '732129008ec7a82d3a040c672dcd33a1', '2025-01-25 16:21:08'),
('17', 'faf15a05558df64861924cd05a9c4f42', '2025-01-25 16:23:38'),
('17', '138fa93ffa0279d7cf7f5c939c185ab6', '2025-01-25 16:59:53'),
('17', 'bbbcf7a28c2d33e83c7a10a52ce2642d', '2025-01-25 17:10:13'),
('17', '9e4e61776594ce2e9f3b02eb8fdc6c6a', '2025-01-25 17:18:12');

-- --------------------------------------------------------

--
-- Table structure for table `guardian`
--

CREATE TABLE `guardian` (
  `ID` int(11) NOT NULL,
  `FIRSTNAME` varchar(80) DEFAULT NULL,
  `MIDDLENAME` varchar(80) DEFAULT NULL,
  `LASTNAME` varchar(80) DEFAULT NULL,
  `CONTACT_NUMBER` varchar(50) DEFAULT NULL,
  `ADDRESS` text DEFAULT NULL,
  `PICTURE` text DEFAULT NULL,
  `EMAIL` varchar(120) DEFAULT NULL,
  `PASSWORD` varchar(120) DEFAULT NULL,
  `STATUS` bit(1) NOT NULL DEFAULT b'1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `guardian`
--

INSERT INTO `guardian` (`ID`, `FIRSTNAME`, `MIDDLENAME`, `LASTNAME`, `CONTACT_NUMBER`, `ADDRESS`, `PICTURE`, `EMAIL`, `PASSWORD`, `STATUS`) VALUES
(17, 'aw', 'z', 'z', '09614376675', 'asdasd', 'iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAYAAAAeP4ixAAAAAXNSR0IArs4c6QAABNFJREFUaEPtmftTGlcYhl+WBUG5mBqjRvFGEkW8VFEBIdFJJp32z+2MM+10OnU0UdBIRLxFA17ilaTqIMpyP52zxsbalN1lF+N0OD8ue/Z8z3m/9zsXVOvhHYL/QVOVQe6YimVF7pggKCtSVqREM1BOrRJNbNGfLStS9NSVqGNZEaGJzWazOIpGsbu3D4CgsbERDXX1YFk1VCqVUHfJv5dEkWAohEAggHT2+saaQMMy6OvtxZDDITlQoQ6KgRBCwCU5TL1+ja3tvQLjEjQ1NuD52Cgq9ZWKqaMYyEUiAb9/DuGtLeTzhY84NLNamy3wetwwVBmEJlvU74qAUD8El5awGFpGOp0RMTCBRqNBt70Tjv5+aFiNiD6FX1EE5Cj6ETN+P6IfPwEQa2SC+zXfYcTlROPDh98ehHpjbX0DM/5ZZDJUDfEgtIINOwbQ29Mj2yuyFaHBB4JBLARDEiC+CNDdZYNzaBBarbz0kg2SSCQw7fMjvLlVFEhriwVetwtGIzW9WDX/nYmyQc4vzjE948Pm9gfpgRCCZksTvB4XzCaT9P7XeGSDJDgOPv8sNsIR6YEQgva2FnjcbhgMVbIMLxuEemR+YQHBxSXpICCw2zrhGh6CVqv9tiC0ai2vrsI3+wa5XF5SMAzDYHDge/T39YFhivcHHVS2IvQj2zsfeMOfxeMSVCEwVFXB5RzCY6tV0gR87WVFQJJJDv65N3i3EQYReQFLtylW6o+REVTq9XcDhKbX/uEBr8rJSUxUUCaTgS+7zRaL7MVQsdS6inxndxfzgbc4Pjnl/UJAbqwMKqjVKlSbzRgcGEB7W6soaDEvKZJa1weKx+MILa/g+PQEHMeBbihpY9Ua6PQ61NyrRm93N0z8uqFcUxzkKjRals/iZ0gkOP6RXq+H0WiEVqNRJJVuTkHJQL4MdN398kpsIf0UB8nlckilU4jFzhCLxcBxSd4rtDKZzCaYTWZUVFSAVauVyyul1hFatZKpFCKbEUQiW+CSSWSzOWSyWeQ/L5KMmgHLsvzlg75CC2t7Gx5ZH0Gn0ymSarIVoWZefbeGxdASuGT68+r+tXT65zM1w0Cno6fELvTYu/kTo5xWNAhVgabOxNQkjqL0ZMgUGUceD2pr8Mz7FPdraopWpyiQfD6Pvf09/Pb7H8hk8nKOEX/Ds6wKL8bG0NLcDHUR/pEMQiHeh8OYmHoFQpStQoyK4Jl3BB1POkA3lFKaJBCaTpHNTUxNzyCVEnNbIiWUy3fpJZ7b5URXZ6ekNJMEcnB4iBmfD5+OTyXscqXDGA1VGH3qgaWpSXRn0SDpdBpz8/NYWVsHTS9FjPEfYdK74SePrfC4nPyaI6aJAqEptfE+zF/50PWilBCXQRNUaLUYHnTA3mUTlWKiQGjwgbdBhJZWSs9wNf2EwNbZAefwIPQ6naAogiBUDeqNickpxM8Tgh9U8oXKSj1GvSN8SRb6K0IQhPphg5bbyVe3kFI3p4HA43bCbrMJri2CIHQDSG8RF/hbkttuBD12GxwD/dDrCh+HBUHi5+eYmJzE/kH0til409fX1WHsmRf3qqsLji8IcnJ6ivFffsXFxeUB6bYb9cmPL1/gQW1tQZ8Igvx5fIyfx8eRTudum4Efj15u//TDSzTU1xUE+Qt9pF5rQSgPpgAAAABJRU5ErkJggg==', 'diolazojames123@gmail.com', '4MX+E5ZVTcmrd7zQHd2Ro2U3emJ3eXNUL0gxaVJ0a293eFlndkE9PQ==', b'1');

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `ID` int(11) NOT NULL,
  `USER_ID` int(11) NOT NULL,
  `TITLE` varchar(200) NOT NULL,
  `REDIRECTION` text NOT NULL,
  `DESCRIPTION` varchar(244) NOT NULL,
  `CREATED_DT` datetime NOT NULL DEFAULT current_timestamp(),
  `STUDENT_ID` int(11) DEFAULT NULL,
  `IS_READ` bit(1) NOT NULL DEFAULT b'0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `token` varchar(64) NOT NULL,
  `expires_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `ID` int(11) NOT NULL,
  `FIRSTNAME` varchar(80) DEFAULT NULL,
  `LASTNAME` varchar(80) DEFAULT NULL,
  `MIDDLENAME` varchar(80) DEFAULT NULL,
  `ADDRESS` text DEFAULT NULL,
  `BIRTHDATE` date DEFAULT NULL,
  `PICTURE` longtext DEFAULT NULL,
  `GRADE_LEVEL` varchar(50) DEFAULT NULL,
  `SECTION` varchar(50) DEFAULT NULL,
  `STATUS` bit(1) NOT NULL DEFAULT b'1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`ID`, `FIRSTNAME`, `LASTNAME`, `MIDDLENAME`, `ADDRESS`, `BIRTHDATE`, `PICTURE`, `GRADE_LEVEL`, `SECTION`, `STATUS`) VALUES
(100022, 'James Patrickss', 'Diolazo', 'Mata', 'asdasd', '2025-01-22', 'iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAYAAAAeP4ixAAAAAXNSR0IArs4c6QAABNFJREFUaEPtmftTGlcYhl+WBUG5mBqjRvFGEkW8VFEBIdFJJp32z+2MM+10OnU0UdBIRLxFA17ilaTqIMpyP52zxsbalN1lF+N0OD8ue/Z8z3m/9zsXVOvhHYL/QVOVQe6YimVF7pggKCtSVqREM1BOrRJNbNGfLStS9NSVqGNZEaGJzWazOIpGsbu3D4CgsbERDXX1YFk1VCqVUHfJv5dEkWAohEAggHT2+saaQMMy6OvtxZDDITlQoQ6KgRBCwCU5TL1+ja3tvQLjEjQ1NuD52Cgq9ZWKqaMYyEUiAb9/DuGtLeTzhY84NLNamy3wetwwVBmEJlvU74qAUD8El5awGFpGOp0RMTCBRqNBt70Tjv5+aFiNiD6FX1EE5Cj6ETN+P6IfPwEQa2SC+zXfYcTlROPDh98ehHpjbX0DM/5ZZDJUDfEgtIINOwbQ29Mj2yuyFaHBB4JBLARDEiC+CNDdZYNzaBBarbz0kg2SSCQw7fMjvLlVFEhriwVetwtGIzW9WDX/nYmyQc4vzjE948Pm9gfpgRCCZksTvB4XzCaT9P7XeGSDJDgOPv8sNsIR6YEQgva2FnjcbhgMVbIMLxuEemR+YQHBxSXpICCw2zrhGh6CVqv9tiC0ai2vrsI3+wa5XF5SMAzDYHDge/T39YFhivcHHVS2IvQj2zsfeMOfxeMSVCEwVFXB5RzCY6tV0gR87WVFQJJJDv65N3i3EQYReQFLtylW6o+REVTq9XcDhKbX/uEBr8rJSUxUUCaTgS+7zRaL7MVQsdS6inxndxfzgbc4Pjnl/UJAbqwMKqjVKlSbzRgcGEB7W6soaDEvKZJa1weKx+MILa/g+PQEHMeBbihpY9Ua6PQ61NyrRm93N0z8uqFcUxzkKjRals/iZ0gkOP6RXq+H0WiEVqNRJJVuTkHJQL4MdN398kpsIf0UB8nlckilU4jFzhCLxcBxSd4rtDKZzCaYTWZUVFSAVauVyyul1hFatZKpFCKbEUQiW+CSSWSzOWSyWeQ/L5KMmgHLsvzlg75CC2t7Gx5ZH0Gn0ymSarIVoWZefbeGxdASuGT68+r+tXT65zM1w0Cno6fELvTYu/kTo5xWNAhVgabOxNQkjqL0ZMgUGUceD2pr8Mz7FPdraopWpyiQfD6Pvf09/Pb7H8hk8nKOEX/Ds6wKL8bG0NLcDHUR/pEMQiHeh8OYmHoFQpStQoyK4Jl3BB1POkA3lFKaJBCaTpHNTUxNzyCVEnNbIiWUy3fpJZ7b5URXZ6ekNJMEcnB4iBmfD5+OTyXscqXDGA1VGH3qgaWpSXRn0SDpdBpz8/NYWVsHTS9FjPEfYdK74SePrfC4nPyaI6aJAqEptfE+zF/50PWilBCXQRNUaLUYHnTA3mUTlWKiQGjwgbdBhJZWSs9wNf2EwNbZAefwIPQ6naAogiBUDeqNickpxM8Tgh9U8oXKSj1GvSN8SRb6K0IQhPphg5bbyVe3kFI3p4HA43bCbrMJri2CIHQDSG8RF/hbkttuBD12GxwD/dDrCh+HBUHi5+eYmJzE/kH0til409fX1WHsmRf3qqsLji8IcnJ6ivFffsXFxeUB6bYb9cmPL1/gQW1tQZ8Igvx5fIyfx8eRTudum4Efj15u//TDSzTU1xUE+Qt9pF5rQSgPpgAAAABJRU5ErkJggg==', 'GRADE 4', 'B', b'1');

-- --------------------------------------------------------

--
-- Table structure for table `student_attendance`
--

CREATE TABLE `student_attendance` (
  `ID` int(11) NOT NULL,
  `STUDENT_ID` varchar(50) NOT NULL,
  `CREATED_DT` date NOT NULL DEFAULT current_timestamp(),
  `TIME_IN` datetime DEFAULT current_timestamp(),
  `TIME_OUT` datetime DEFAULT NULL,
  `AUTHORIZE_ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `student_guardian`
--

CREATE TABLE `student_guardian` (
  `STUDENT_NUMBER` int(11) NOT NULL,
  `PARENT_ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `student_guardian`
--

INSERT INTO `student_guardian` (`STUDENT_NUMBER`, `PARENT_ID`) VALUES
(1, 1),
(2, 1),
(100003, 4),
(100004, 5),
(100003, 4),
(100004, 5),
(100013, 10),
(100014, 11),
(100018, 13),
(100019, 14),
(100020, 15),
(100021, 16),
(100022, 17);

-- --------------------------------------------------------

--
-- Table structure for table `student_qrcode`
--

CREATE TABLE `student_qrcode` (
  `ID` int(11) NOT NULL,
  `QR_CODE` text DEFAULT NULL,
  `STUDENT_NUMBER` int(11) NOT NULL,
  `STATUS` bit(1) NOT NULL DEFAULT b'1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `student_qrcode`
--

INSERT INTO `student_qrcode` (`ID`, `QR_CODE`, `STUDENT_NUMBER`, `STATUS`) VALUES
(27, '202501251305491000226WT8tE4yHgBJsuDS', 100022, b'1');

-- --------------------------------------------------------

--
-- Table structure for table `teachers`
--

CREATE TABLE `teachers` (
  `ID` int(11) NOT NULL,
  `FIRSTNAME` varchar(80) DEFAULT NULL,
  `MIDDLENAME` varchar(80) DEFAULT NULL,
  `LASTNAME` varchar(80) DEFAULT NULL,
  `BIRTHDATE` date DEFAULT NULL,
  `ADDRESS` text DEFAULT NULL,
  `CONTACT_NUMBER` varchar(50) DEFAULT NULL,
  `PICTURE` longtext DEFAULT NULL,
  `EMAIL` varchar(120) DEFAULT NULL,
  `PASSWORD` varchar(120) DEFAULT NULL,
  `STATUS` bit(1) NOT NULL DEFAULT b'1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `teachers`
--

INSERT INTO `teachers` (`ID`, `FIRSTNAME`, `MIDDLENAME`, `LASTNAME`, `BIRTHDATE`, `ADDRESS`, `CONTACT_NUMBER`, `PICTURE`, `EMAIL`, `PASSWORD`, `STATUS`) VALUES
(10, 'james', 'a', 'diolazoa', '2025-01-22', 'asdasdasdasd', '09614376675', 'iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAYAAAAeP4ixAAAAAXNSR0IArs4c6QAABNFJREFUaEPtmftTGlcYhl+WBUG5mBqjRvFGEkW8VFEBIdFJJp32z+2MM+10OnU0UdBIRLxFA17ilaTqIMpyP52zxsbalN1lF+N0OD8ue/Z8z3m/9zsXVOvhHYL/QVOVQe6YimVF7pggKCtSVqREM1BOrRJNbNGfLStS9NSVqGNZEaGJzWazOIpGsbu3D4CgsbERDXX1YFk1VCqVUHfJv5dEkWAohEAggHT2+saaQMMy6OvtxZDDITlQoQ6KgRBCwCU5TL1+ja3tvQLjEjQ1NuD52Cgq9ZWKqaMYyEUiAb9/DuGtLeTzhY84NLNamy3wetwwVBmEJlvU74qAUD8El5awGFpGOp0RMTCBRqNBt70Tjv5+aFiNiD6FX1EE5Cj6ETN+P6IfPwEQa2SC+zXfYcTlROPDh98ehHpjbX0DM/5ZZDJUDfEgtIINOwbQ29Mj2yuyFaHBB4JBLARDEiC+CNDdZYNzaBBarbz0kg2SSCQw7fMjvLlVFEhriwVetwtGIzW9WDX/nYmyQc4vzjE948Pm9gfpgRCCZksTvB4XzCaT9P7XeGSDJDgOPv8sNsIR6YEQgva2FnjcbhgMVbIMLxuEemR+YQHBxSXpICCw2zrhGh6CVqv9tiC0ai2vrsI3+wa5XF5SMAzDYHDge/T39YFhivcHHVS2IvQj2zsfeMOfxeMSVCEwVFXB5RzCY6tV0gR87WVFQJJJDv65N3i3EQYReQFLtylW6o+REVTq9XcDhKbX/uEBr8rJSUxUUCaTgS+7zRaL7MVQsdS6inxndxfzgbc4Pjnl/UJAbqwMKqjVKlSbzRgcGEB7W6soaDEvKZJa1weKx+MILa/g+PQEHMeBbihpY9Ua6PQ61NyrRm93N0z8uqFcUxzkKjRals/iZ0gkOP6RXq+H0WiEVqNRJJVuTkHJQL4MdN398kpsIf0UB8nlckilU4jFzhCLxcBxSd4rtDKZzCaYTWZUVFSAVauVyyul1hFatZKpFCKbEUQiW+CSSWSzOWSyWeQ/L5KMmgHLsvzlg75CC2t7Gx5ZH0Gn0ymSarIVoWZefbeGxdASuGT68+r+tXT65zM1w0Cno6fELvTYu/kTo5xWNAhVgabOxNQkjqL0ZMgUGUceD2pr8Mz7FPdraopWpyiQfD6Pvf09/Pb7H8hk8nKOEX/Ds6wKL8bG0NLcDHUR/pEMQiHeh8OYmHoFQpStQoyK4Jl3BB1POkA3lFKaJBCaTpHNTUxNzyCVEnNbIiWUy3fpJZ7b5URXZ6ekNJMEcnB4iBmfD5+OTyXscqXDGA1VGH3qgaWpSXRn0SDpdBpz8/NYWVsHTS9FjPEfYdK74SePrfC4nPyaI6aJAqEptfE+zF/50PWilBCXQRNUaLUYHnTA3mUTlWKiQGjwgbdBhJZWSs9wNf2EwNbZAefwIPQ6naAogiBUDeqNickpxM8Tgh9U8oXKSj1GvSN8SRb6K0IQhPphg5bbyVe3kFI3p4HA43bCbrMJri2CIHQDSG8RF/hbkttuBD12GxwD/dDrCh+HBUHi5+eYmJzE/kH0til409fX1WHsmRf3qqsLji8IcnJ6ivFffsXFxeUB6bYb9cmPL1/gQW1tQZ8Igvx5fIyfx8eRTudum4Efj15u//TDSzTU1xUE+Qt9pF5rQSgPpgAAAABJRU5ErkJggg==', 'diolazojames123123@gmail.com', 'z4ZBat5XKWKBok3toSuA/GZndGs4cW9JOU96ZFJoblR5NnlDaEE9PQ==', b'1');

-- --------------------------------------------------------

--
-- Table structure for table `teacher_students`
--

CREATE TABLE `teacher_students` (
  `TEACHER_ID` int(11) NOT NULL,
  `STUDENT_ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_staff`
--
ALTER TABLE `admin_staff`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `authorize_person`
--
ALTER TABLE `authorize_person`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `guardian`
--
ALTER TABLE `guardian`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `student_attendance`
--
ALTER TABLE `student_attendance`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `student_qrcode`
--
ALTER TABLE `student_qrcode`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `teachers`
--
ALTER TABLE `teachers`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_staff`
--
ALTER TABLE `admin_staff`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `authorize_person`
--
ALTER TABLE `authorize_person`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=129;

--
-- AUTO_INCREMENT for table `guardian`
--
ALTER TABLE `guardian`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=66;

--
-- AUTO_INCREMENT for table `password_resets`
--
ALTER TABLE `password_resets`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=100023;

--
-- AUTO_INCREMENT for table `student_attendance`
--
ALTER TABLE `student_attendance`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=110;

--
-- AUTO_INCREMENT for table `student_qrcode`
--
ALTER TABLE `student_qrcode`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `teachers`
--
ALTER TABLE `teachers`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
