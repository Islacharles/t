<?php 
include '../../Config/api-config.php';
include '../../Config/connection.php'; // openning connection

// Get the student ID to archive
$studentId = $_POST['student_id']; // or from URL, $_GET['student_id'] if needed

// Start a transaction to ensure all archive operations succeed or fail together
$conn->begin_transaction();

try {
    // archive from student_guardian table
    // $sql1 = "archive FROM student_guardian WHERE STUDENT_NUMBER = ?";
    // $stmt1 = $conn->prepare($sql1);
    // $stmt1->bind_param("i", $studentId);
    // $stmt1->execute();

    // archive from guardian table (make sure guardian exists for this student)
    // $sql2 = "archive FROM guardian WHERE ID IN (SELECT PARENT_ID FROM student_guardian WHERE STUDENT_NUMBER = ?)";
    // $stmt2 = $conn->prepare($sql2);
    // $stmt2->bind_param("i", $studentId);
    // $stmt2->execute();

    // archive from students table
    $sql ="UPDATE students SET `STATUS` = b'0'  WHERE ID = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $studentId);
    $stmt->execute();

    // Commit the transaction
    $conn->commit();

    $response = array(
        'status' => 'success',
        'message' => 'Student and related records archived successfully!'
    );
    // Send the response as JSON
    echo json_encode($response); 
} catch (Exception $e) {
    // Rollback the transaction in case of error
    $conn->rollback();
    echo "Error: " . $e->getMessage();
}

// Close the prepared statements and connection
$stmt->close();
// $stmt2->close();
// $stmt3->close();
$conn->close();

?>