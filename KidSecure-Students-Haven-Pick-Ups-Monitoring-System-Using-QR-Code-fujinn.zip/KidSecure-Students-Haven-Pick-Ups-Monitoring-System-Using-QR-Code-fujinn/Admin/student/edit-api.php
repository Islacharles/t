<?php
include '../../Config/api-config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST'){
    exit();
}

// Collect data from POST
$studentId = $_POST["StudentId"] ?? '';
$firstName = $_POST["FirstName"] ?? '';
$middleName = $_POST["MiddleName"] ?? '';
$lastName = $_POST["LastName"] ?? '';
$birthDate = $_POST["BirthDate"] ?? '';
$gradeLevel = $_POST["GradeLevel"] ?? '';
$section = $_POST["Section"] ?? '';
$address = $_POST["Address"] ?? '';
$guardianId = $_POST["GuardianId"] ?? '';
$guardianFirstName = $_POST["GuardianFirstName"] ?? '';
$guardianMiddleName = $_POST["GuardianMiddleName"] ?? '';
$guardianLastName = $_POST["GuardianLastName"] ?? '';
$guardianContactNumber = $_POST["GuardianContactNumber"] ?? '';
$guardianAddress = $_POST["GuardianAddress"] ?? '';
$guardianEmail = $_POST["GuardianEmail"] ?? '';

$StudentPIctureBase64 = $_POST['StudentPIctureBase64'];
$GuardianPIctureBase64 = $_POST['GuardianPIctureBase64'];

// Initialize an array to store validation errors
$validationErrors = [];

// Validate each field
$validationErrors['FirstName'] = validateField('FirstName', $firstName);
// $validationErrors['MiddleName'] = validateField('MiddleName', $middleName);
$validationErrors['LastName'] = validateField('LastName', $lastName);
$validationErrors['GradeLevel'] = validateField('GradeLevel', $gradeLevel);
$validationErrors['Section'] = validateField('Section', $section);
$validationErrors['Address'] = validateField('Address', $address, 100);
$validationErrors['GuardianFirstName'] = validateField('GuardianFirstName', $guardianFirstName);
// $validationErrors['GuardianMiddleName'] = validateField('GuardianMiddleName', $guardianMiddleName);
$validationErrors['GuardianLastName'] = validateField('GuardianLastName', $guardianLastName);
$validationErrors['GuardianContactNumber'] = validateField('GuardianContactNumber', $guardianContactNumber, 15);
$validationErrors['GuardianAddress'] = validateField('GuardianAddress', $guardianAddress, 100);

// Validate BirthDate (example: required and valid date format)
if (empty($birthDate)) {
    $validationErrors['BirthDate'][] = "BirthDate is required.";
} elseif (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $birthDate)) {
    $validationErrors['BirthDate'][] = "BirthDate must be in the format YYYY-MM-DD.";
}

if(empty($StudentPIctureBase64)){
    $validationErrors['imgUser'] = "User Image is required";
}

if(empty($GuardianPIctureBase64)){
    $validationErrors['imgGuardianUser'] = "User Image is required";
}

// Validate GuardianEmail (example: required and valid email format)
if (empty($guardianEmail)) {
    $validationErrors['GuardianEmail'][] = "GuardianEmail is required.";
} elseif (!filter_var($guardianEmail, FILTER_VALIDATE_EMAIL)) {
    $validationErrors['GuardianEmail'][] = "Please provide a valid email address for the guardian.";
}

// Remove fields with no errors
foreach ($validationErrors as $key => $value) {
    if (empty($value)) {
        unset($validationErrors[$key]);
    }
}

// Respond with validation errors
if (!empty($validationErrors)) {
    echo json_encode($validationErrors, JSON_PRETTY_PRINT);
    exit();
}


include '../../Config/connection.php'; // openning connection

$sql = "UPDATE students
        SET 
            FIRSTNAME = ?, 
            LASTNAME = ?, 
            MIDDLENAME = ?, 
            ADDRESS = ?, 
            BIRTHDATE = ?, 
            GRADE_LEVEL = ?, 
            SECTION = ?,
            PICTURE = ?
        WHERE 
            ID = ?";
// Prepare the statement
$stmt = $conn->prepare($sql);

// Bind parameters to the statement
$stmt->bind_param("sssssssss",
    $firstName, 
    $lastName, 
    $middleName, 
    $address, 
    $birthDate, 
    $gradeLevel, 
    $section,
    $StudentPIctureBase64,
    $studentId); // "sss" denotes that all parameters are strings


// Execute the query
$stmt->execute();

$guardianSql = "UPDATE guardian
                SET 
                    FIRSTNAME = ?, 
                    MIDDLENAME = ?, 
                    LASTNAME = ?, 
                    CONTACT_NUMBER = ?, 
                    ADDRESS = ?, 
                    PICTURE = ?, 
                    EMAIL = ?
                WHERE 
                    ID = ?";

// Prepare the statement
$guardianstmt = $conn->prepare($guardianSql);

// Bind parameters to the statement
$guardianstmt->bind_param("ssssssss", 
    $guardianFirstName, 
    $guardianMiddleName, 
    $guardianLastName, 
    $guardianContactNumber, 
    $guardianAddress, 
    $GuardianPIctureBase64, 
    $guardianEmail,
    $guardianId
);
$guardianstmt->execute();
 
// Close the statement and the connection
$stmt->close();  
$guardianstmt->close();
$conn->close(); 

$response = array(
    'status' => 'success',
    'message' => 'Record updated successfully!'
);
// Send the response as JSON
echo json_encode($response);
// Helper function to validate input fields
function validateField($fieldName, $fieldValue, $maxLength = 50) {
    $errors = [];

    // Check if the field is required and not empty
    if (empty($fieldValue)) {
        $errors[] = "$fieldName is required.";
    }

    // Check length
    if (!empty($fieldValue) && strlen($fieldValue) > $maxLength) {
        $errors[] = "$fieldName must not exceed $maxLength characters.";
    }

    // Check for special characters
    if (!empty($fieldValue) && preg_match('/[^a-zA-Z0-9\s]/', $fieldValue)) {
        $errors[] = "$fieldName must not contain special characters.";
    }

    return $errors;
}
?>