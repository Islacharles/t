<?php
include '../../Config/api-config.php';
// Include the database connection
include '../../Config/connection.php';


// Check if the required parameters are sent in the POST request
if (isset($_POST['student_id'])) {
    $studentId = $_POST['student_id']; // The student ID

    // Get the current datetime in 'yyyyMMddHHmmss' format
    $dateTime = date('YmdHis');
    // Generate a 16-character random string (letters and numbers)
    $randomString = substr(str_shuffle('ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789'), 0, 16);
    // Combine the datetime, fixed value, and random string
    $finalString = $dateTime . $studentId . $randomString;

    // Start a transaction to ensure both operations (delete and insert) are handled together
    $conn->begin_transaction();

    try {
        // Step 1: Delete existing QR code record for the student
        $deleteSql = "DELETE FROM student_qrcode WHERE STUDENT_NUMBER = ?";
        $deleteStmt = $conn->prepare($deleteSql);
        $deleteStmt->bind_param("i", $studentId);
        $deleteStmt->execute();
        // Close statements and connection
        $deleteStmt->close();

        // Step 2: Insert the new QR code for the student
        $insertSql = "INSERT INTO student_qrcode (STUDENT_NUMBER, QR_CODE) VALUES (?, ?);";
        $insertStmt = $conn->prepare($insertSql);
        $insertStmt->bind_param("ss", $studentId, $finalString);
        $insertStmt->execute();
        $insertStmt->close();

        // Commit the transaction
        $conn->commit();

        // If the update was successful
        $response = array(
            'status' => 'success',
            'message' => ('QR code updated successfully ')
        );
    } catch (Exception $e) {
        // Rollback the transaction in case of error
        $conn->rollback();
        // If there was an error executing the query
        $response = array(
            'status' => 'error',
            'message' => 'Failed to update QR code'
        );
    }

} else {
    // If required parameters are missing
    $response = array(
        'status' => 'error',
        'message' => 'Missing required parameters' . $_POST['student_id']
    );
}
// Close the database connection
$conn->close();

// Send the JSON response
echo json_encode($response);


?>
