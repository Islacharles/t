<?php
session_start(); // Start the session
include '../../Config/connection.php';
include '../../Config/auth.php';
$_SESSION['header'] = 'Students';
?>

<!DOCTYPE html>
<html>
<head>
    <title>Student Records</title>
    <link href="css/styles.css" rel="stylesheet" />
    <link href="index.css" rel="stylesheet" />
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
    <link href="https://cdn.datatables.net/buttons/2.3.6/css/buttons.dataTables.min.css" rel="stylesheet">
</head>
<body>
    <?php include '../shared/sidebar.php'; ?>
    <div class="container-main">
        <div class="main-wrapper-body card-container">
            <div class="row">
                <div class="col-md-12">
                    <div class="search-field mb-3" style="display: flex; justify-content: space-between; align-items: center;">
                        <h4>Student Records</h4>
                        <div>
                            <a href="create.php" type="button" class="btn btn-primary" style="margin-right: 10px;">Create Student & Parent Account</a>
                            <form action="export-studentlist-api.php" method="POST" style="display: inline;">
                                <!-- <button type="submit" name="generate_excel" class="btn btn-success" style="margin-right: 10px;">Generate Student Records</button> -->
                            </form>
                            <button type="button" class="btn btn-danger" style="margin-left: 10px;" id="viewArchived" data-bs-toggle="modal" data-bs-target="#archivedModal"> View Archived Students </button>
                        </div>
                    </div>
                    <table class="table table-bordered table-hover align-middle" id="GuardianTable">
                        <thead class="table-dark">
                            <tr>
                                <th>Picture</th>
                                <th>Student Number</th>
                                <th>Full Name</th>
                                <th>Grade</th>
                                <th>Section</th>
                                <th>Parent Name</th>
                                <th>Contact Number</th>
                                <th>Email</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody id="table-body">
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <!-- Archived Students Modal -->
<div class="modal fade" id="archivedModal" tabindex="-1" aria-labelledby="archivedModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="archivedModalLabel">Archived Students</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <table class="table table-bordered table-hover align-middle" id="ArchivedTable">
                    <thead class="table-dark">
                        <tr>
                            <th>Picture</th>
                            <th>Student Number</th>
                            <th>Full Name</th>
                            <th>Grade</th>
                            <th>Section</th>
                            <th>Parent Name</th>
                            <th>Contact Number</th>
                            <th>Email</th>
                        </tr>
                    </thead>
                    <tbody></tbody>
                </table>
            </div>
        </div>
    </div>
</div>
    <script>
        $(document).ready(function () {
            const table = $('#GuardianTable').DataTable({
                dom: '<"row"<"col-md-6"l><"col-md-6 text-end"Bf>>rtip',  // This defines the layout for DataTable buttons
                buttons: ['copy', 'csv', 'excel', 'pdf', 'print'], // Adding buttons for export and print
                ajax: {
                    url: 'index-search-api.php',
                    type: 'GET',
                    dataSrc: ''
                },
                columns: [
                    {
                        data: 'picture',
                        render: function (data) {
                            return `<img src="data:image/png;base64,${data}" class="table-img" alt="N/A">`;
                        }
                    },
                    { data: 'student_number' },
                    { data: 'student_name' },
                    { data: 'grade_level' },
                    { data: 'section' },
                    { data: 'guardian_name' },
                    { data: 'guardian_contact' },
                    { data: 'guardian_email' },
                    {
                        data: 'student_number',
                        render: function (data) {
                            return `
                                <a class="btn btn-dark btn-sm" href="view.php?id=${data}">View</a>
                                <a class="btn btn-info btn-sm text-white" href="edit.php?id=${data}" style="color: #4A3AFF">Edit</a>
                                <button class="btn btn-danger btn-sm btnDelete" data-id="${data}">Archive</button>
                            `;
                        }
                    }
                ]
            });

            // Delete Functionality
            $('#GuardianTable').on('click', '.btnDelete', function () {
                const studentId = $(this).data('id');
                if (confirm('Are you sure you want to delete this student?')) {
                    $.ajax({
                        url: 'delete-api.php',
                        type: 'POST',
                        data: { student_id: studentId },
                        success: function (response) {
                            alert(response?.message || 'Student archive successfully.');
                            table.ajax.reload(); // Reload DataTable
                        },
                        error: function () {
                            alert('An error occurred while archiving the student.');
                        }
                    });
                }
            });
        });
            $(document).ready(function () {
                const archivedTable = $('#ArchivedTable').DataTable({
                    ajax: {
                        url: 'fetch-archived-students-api.php',
                        type: 'GET',
                        dataSrc: ''
                    },
                    columns: [
                        {
                        data: 'picture',
                        render: function (data) {
                            return `<img src="data:image/png;base64,${data}" class="table-img" alt="N/A">`;
                        }
                        },
                        { data: 'student_number' },
                        { data: 'student_name' },
                        { data: 'grade_level' },
                        { data: 'section' },
                        { data: 'guardian_name' },
                        { data: 'guardian_contact' },
                        { data: 'guardian_email' },
                    ]
                });
            });
    </script>

    <style>
        .table-img {
            width: 50px;
            height: 50px;
            object-fit: cover;
            border-radius: 50%;
        }
        .search-field h4 {
            margin: 0;
        }
        .search-field > div {
            display: flex;
            align-items: center;
        }
    </style>
</body>
</html>
