<?php 
include '../../Config/api-config.php';
include '../../Config/connection.php'; // Opening connection

// Get the teacher ID to archive
$teacherId = $_POST['teacher_id']; // Get from POST request, can also use $_GET if needed

// Start a transaction to ensure all archive operations succeed or fail together
$conn->begin_transaction();

try {
    // archive the teacher record from the `teachers` table
    $sql = "UPDATE teachers SET `STATUS` = b'0'  WHERE ID = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $teacherId);
    $stmt->execute();

    // Commit the transaction
    $conn->commit();

    // Prepare the response
    $response = array(
        'status' => 'success',
        'message' => 'Teacher record archived successfully!'
    );

    // Send the response as JSON
    echo json_encode($response); 
} catch (Exception $e) {
    // Rollback the transaction in case of error
    $conn->rollback();
    $response = array(
        'status' => 'error',
        'message' => 'Error: ' . $e->getMessage()
    );
    echo json_encode($response);
}

// Close the prepared statements and connection
$stmt->close();
$conn->close();
?>
