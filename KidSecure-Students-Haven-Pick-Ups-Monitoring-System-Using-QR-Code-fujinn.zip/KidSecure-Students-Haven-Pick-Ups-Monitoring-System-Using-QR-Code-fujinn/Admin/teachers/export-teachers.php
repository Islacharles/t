<?php
// Include necessary configuration and database connection files
include '../../Config/api-config.php';
include '../../Config/connection.php'; // Opening connection
require '../../vendor/autoload.php'; // Include PhpSpreadsheet

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use PhpOffice\PhpSpreadsheet\Style\Border;
use PhpOffice\PhpSpreadsheet\Style\Color;

// Get the search parameter
$search = $_GET['search'] ?? '';

// SQL query to fetch teachers
$sql = "SELECT 
            *
        FROM 
            teachers
        WHERE 
            CONCAT(FIRSTNAME, MIDDLENAME, LASTNAME, EMAIL, CONTACT_NUMBER) LIKE ?";

// Prepare the statement
$stmt = $conn->prepare($sql);

if (!$stmt) {
    echo json_encode(['error' => 'Failed to prepare the statement.']);
    exit();
}

// Add wildcards for the search term
$searchTermWithWildcards = "%" . $search . "%";  

// Bind parameter (s for string)
$stmt->bind_param("s", $searchTermWithWildcards);

// Execute the query
$stmt->execute();

// Get the result
$result = $stmt->get_result();

// Initialize PhpSpreadsheet object
$spreadsheet = new Spreadsheet();
$sheet = $spreadsheet->getActiveSheet();

// Add Title Row "TEACHER RECORDS"
$sheet->mergeCells('A1:F1'); // Merge cells for the title
$sheet->setCellValue('A1', 'TEACHER RECORDS');

// Apply styles to the title
$titleStyle = [
    'font' => [
        'bold' => true,
        'size' => 16,
        'color' => ['rgb' => 'FFFFFF'],
    ],
    'alignment' => [
        'horizontal' => Alignment::HORIZONTAL_CENTER,
        'vertical' => Alignment::VERTICAL_CENTER,
    ],
    'fill' => [
        'fillType' => Fill::FILL_SOLID,
        'startColor' => ['rgb' => '4F81BD'], // Blue background
    ],
    'borders' => [
        'bottom' => [
            'borderStyle' => Border::BORDER_THIN,
            'color' => ['rgb' => '000000'],
        ],
    ],
];
$sheet->getStyle('A1:F1')->applyFromArray($titleStyle);

// Set headers for the Excel sheet (starting from row 2)
$sheet->setCellValue('A2', 'Teacher ID')
      ->setCellValue('B2', 'Teacher Name')
      ->setCellValue('C2', 'Birthdate')
      ->setCellValue('D2', 'Address')
      ->setCellValue('E2', 'Contact Number')
      ->setCellValue('F2', 'Email');

// Apply styles to headers
$headerStyle = [
    'font' => [
        'bold' => true,
        'color' => ['rgb' => 'FFFFFF'],
    ],
    'alignment' => [
        'horizontal' => Alignment::HORIZONTAL_CENTER,
        'vertical' => Alignment::VERTICAL_CENTER,
    ],
    'fill' => [
        'fillType' => Fill::FILL_SOLID,
        'startColor' => ['rgb' => '4F81BD'],
    ],
    'borders' => [
        'allBorders' => [
            'borderStyle' => Border::BORDER_THIN,
            'color' => ['rgb' => '000000'],
        ],
    ],
];
$sheet->getStyle('A2:F2')->applyFromArray($headerStyle);

// Fetch and add the data rows to the spreadsheet
$rowIndex = 3; // Start from row 3 (after title and headers)
while ($row = $result->fetch_assoc()) {
    $sheet->setCellValue('A' . $rowIndex, $row["ID"])
          ->setCellValue('B' . $rowIndex, $row["FIRSTNAME"] . " " . $row["MIDDLENAME"] . " " . $row["LASTNAME"])
          ->setCellValue('C' . $rowIndex, $row["BIRTHDATE"])
          ->setCellValue('D' . $rowIndex, $row["ADDRESS"])
          ->setCellValue('E' . $rowIndex, $row["CONTACT_NUMBER"])
          ->setCellValue('F' . $rowIndex, $row["EMAIL"]);

    // Apply border style to each data row
    $sheet->getStyle('A' . $rowIndex . ':F' . $rowIndex)->applyFromArray([
        'borders' => [
            'allBorders' => [
                'borderStyle' => Border::BORDER_THIN,
                'color' => ['rgb' => '000000'],
            ],
        ],
    ]);

    $rowIndex++;
}

// Set the column width for better readability
$sheet->getColumnDimension('A')->setWidth(15);
$sheet->getColumnDimension('B')->setWidth(30);
$sheet->getColumnDimension('C')->setWidth(15);
$sheet->getColumnDimension('D')->setWidth(40);
$sheet->getColumnDimension('E')->setWidth(20);
$sheet->getColumnDimension('F')->setWidth(30);

// Set headers for file download
header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment;filename="teacher_lists.xlsx"');
header('Cache-Control: max-age=0');

// Create writer and output the Excel file
$writer = new Xlsx($spreadsheet);
$writer->save('php://output');

// Close the statement and connection
$stmt->close();
$conn->close();
exit();
?>
