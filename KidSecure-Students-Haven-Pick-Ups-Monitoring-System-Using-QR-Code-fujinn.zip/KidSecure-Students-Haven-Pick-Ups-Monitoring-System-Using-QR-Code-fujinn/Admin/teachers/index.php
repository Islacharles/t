<?php
session_start(); // Start the session
include '../../Config/connection.php';
include '../../Config/auth.php';

$_SESSION['header'] = 'Teachers';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Teachers Record</title>
    <link href="index.css" rel="stylesheet"/>
    <!-- DataTables CSS -->
    <link rel="stylesheet" href="dataTables.min.css">
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
    <style>
        .table-img {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            object-fit: cover;
        }
    </style>
</head>
<body>
    <?php include '../shared/sidebar.php'; ?>
    <div class="container-main">
        <div class="main-wrapper-body">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h4>Teachers Records</h4>
            <div>
                <a href="create.php" class="btn btn-primary">Create Teacher</a>
                <form action="export-teachers.php" method="POST" style="display: inline;">
                    <!-- <button type="submit" name="generate_excel" class="btn btn-success">Generate Teacher Records</button> -->
                    </form>
                <button type="button" class="btn btn-danger" id="viewArchived" data-bs-toggle="modal" data-bs-target="#archivedModal"> View Archived </button>
            </div>
        </div>
            <div class="table-responsive">
                <table class="table table-bordered table-hover align-middle" id="TeachersTable">
                    <thead class="table-dark">
                        <tr>
                            <th>Picture</th>
                            <th>Full Name</th>
                            <th>Email</th>
                            <th>Contact Number</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <!-- Data populated dynamically -->
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <!-- Archived Teacher Modal -->
<div class="modal fade" id="archivedModal" tabindex="-1" aria-labelledby="archivedModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="archivedModalLabel">Archived Students</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <table class="table table-bordered table-hover align-middle" id="ArchivedTable">
                    <thead class="table-dark">
                        <tr>
                            <th>Picture</th>
                            <th>Full Name</th>
                            <th>Email</th>
                            <th>Contact Number</th>
                        </tr>
                    </thead>
                    <tbody></tbody>
                </table>
            </div>
        </div>
    </div>
</div>
    
    <script>
        $(document).ready(function () {
        // Initialize DataTable
        const table = $('#TeachersTable').DataTable({
            dom: '<"row"<"col-md-6"l><"col-md-6 text-end"Bf>>rtip',  // This defines the layout for DataTable buttons
            buttons: ['copy', 'csv', 'excel', 'pdf', 'print'], // Adding buttons for export and print
            ajax: {
                    url: 'index-search-api.php',
                    type: 'GET',
                    dataSrc: ''
                },
                
                columns: [
                    {
                        data: 'picture',
                        render: function (data) {
                            return `<img src="data:image/png;base64,${data}" class="table-img" alt="N/A">`;
                        }
                    },
                    { data: 'teacher_name' },
                    { data: 'email' },
                    { data: 'contact_number' },
                    {
                        data: 'teacher_id',
                        render: function (data, type, row) {
                            return `
                                <button class="btn btn-sm btn-primary btnReset" data-id="${data}" data-pw="${row.default_data}">Reset Password</button>
                                <a class="btn btn-info btn-sm text-white" href="edit.php?id=${data}" style="color: #4A3AFF">Edit</a>
                                <a href="view.php?id=${data}" class="btn btn-dark btn-sm">View</a>
                                <button class="btn btn-sm btn-danger btnDelete" data-id="${data}">Archive</button>
                            `;
                        }
                    }
                ],
                
            });

            // Reset Password Handler
            $('#TeachersTable').on('click', '.btnReset', function () {
                const teacherId = $(this).data('id');
                const defaultPw = $(this).data('pw');
                if (confirm('Are you sure you want to reset this teacher\'s password?')) {
                    $.ajax({
                        url: 'reset-api.php',
                        type: 'POST',
                        data: { teacher_id: teacherId, defaultpw: defaultPw },
                        success: function (response) {
                            alert(response?.message || 'Password reset successfully.');
                        },
                        error: function () {
                            alert('An error occurred while resetting the password.');
                        }
                    });
                }
            });

            // Delete Teacher Handler
            $('#TeachersTable').on('click', '.btnDelete', function () {
                const teacherId = $(this).data('id');
                if (confirm('Are you sure you want to archive this teacher?')) {
                    $.ajax({
                        url: 'delete-api.php',
                        type: 'POST',
                        data: { teacher_id: teacherId },
                        success: function (response) {
                            alert(response?.message || 'Teacher archived successfully.');
                            table.ajax.reload(); // Reload the DataTable
                        },
                        error: function () {
                            alert('An error occurred while deleting the teacher.');
                        }
                    });
                }
            });
        });
        $(document).ready(function () {
                const archivedTable = $('#ArchivedTable').DataTable({
                    ajax: {
                        url: 'fetch-archived-teacher-api.php',
                        type: 'GET',
                        dataSrc: ''
                    },
                    columns: [
                    {
                        data: 'picture',
                        render: function (data) {
                            return `<img src="data:image/png;base64,${data}" class="table-img" alt="N/A">`;
                        }
                    },
                    { data: 'teacher_name' },
                    { data: 'email' },
                    { data: 'contact_number' }
                    ]
                });
            });
    </script>
</body>
</html>
