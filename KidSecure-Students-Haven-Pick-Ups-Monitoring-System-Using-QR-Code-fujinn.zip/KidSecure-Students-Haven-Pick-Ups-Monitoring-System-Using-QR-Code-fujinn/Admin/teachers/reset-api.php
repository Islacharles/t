<?php
include '../../Config/api-config.php';  // Database configuration
include '../../Config/connection.php'; // Open connection
include '../../Config/encryption.php'; // Encryption functions

// Get data from POST request
$teacherId = $_POST['teacher_id'] ?? '';
$defaultPword = $_POST['defaultpw'] ?? '';

// Validate required fields
if (empty($teacherId) || empty($defaultPword)) {
    echo json_encode(['error' => 'Teacher ID and new password are required']);
    exit();
}

// Encrypt the password
$encryptedPword = encrypt($defaultPword);

// SQL query to update the password
$updateSql = "UPDATE teachers SET PASSWORD = ? WHERE ID = ?";
$updateStmt = $conn->prepare($updateSql);

// Bind parameters (s for string)
$updateStmt->bind_param("ss", $encryptedPword, $teacherId);

// Execute the update
if ($updateStmt->execute()) {
    $response = array(
        'status' => 'success',
        'message' => 'Password reset successfully!'
    );
} else {
    $response = array(
        'status' => 'error',
        'message' => 'Failed to update password: ' . $updateStmt->error
    );
}

// Send the response as JSON
echo json_encode($response);

// Close the statements and connection
$updateStmt->close();
$conn->close();
?>
