<?php
include '../../Config/api-config.php';
include '../../Config/connection.php'; // openning connection

// Read the incoming POST request
$request = json_decode(file_get_contents('php://input'), true);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if an action is provided
    if (!isset($request['action'])) {
        echo json_encode(["error" => "Action is required."]);
        exit();
    }

    $action = $request['action'];

    // Handle actions
    switch ($action) {
        case 'create':
            createTeacher($conn, $request);
            break;

        case 'read':
            readTeachers($conn, $request);
            break;

        case 'update':
            updateTeacher($conn, $request);
            break;

        case 'delete':
            deleteTeacher($conn, $request);
            break;

        default:
            echo json_encode(["error" => "Invalid action."]);
            break;
    }
} else {
    echo json_encode(["error" => "Only POST requests are supported."]);
    exit();
}

// Functions for CRUD operations

// Create Teacher
function createTeacher($conn, $data) {
    $firstname = $data['FIRSTNAME'] ?? null;
    $middlename = $data['MIDDLENAME'] ?? null;
    $lastname = $data['LASTNAME'] ?? null;
    $birthdate = $data['BIRTHDATE'] ?? null;
    $address = $data['ADDRESS'] ?? null;
    $contact_number = $data['CONTACT_NUMBER'] ?? null;
    $picture = $data['PICTURE'] ?? null;
    $email = $data['EMAIL'] ?? null;
    $password = strtolower($data['FIRSTNAME'] ?? '') . strtolower($data['LASTNAME'] ?? '');

    if (!$firstname || !$lastname || !$email || !$password) {
        echo json_encode(["error" => "Required fields are missing."]);
        return;
    }

    $password = password_hash($password, PASSWORD_BCRYPT); // Encrypt password

    $sql = "INSERT INTO teachers (FIRSTNAME, MIDDLENAME, LASTNAME, BIRTHDATE, ADDRESS, CONTACT_NUMBER, PICTURE, EMAIL, PASSWORD) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('sssssssss', $firstname, $middlename, $lastname, $birthdate, $address, $contact_number, $picture, $email, $password);

    if ($stmt->execute()) {
        echo json_encode(["success" => "Teacher created successfully!", "id" => $stmt->insert_id]);
    } else {
        echo json_encode(["error" => $stmt->error]);
    }

    $stmt->close();
}

// Read Teachers
function readTeachers($conn, $data) {
    $id = $data['ID'] ?? null;

    if ($id) {
        // Fetch a single teacher by ID
        $sql = "SELECT * FROM teachers WHERE ID = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param('i', $id);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $teacher = $result->fetch_assoc();
            echo json_encode($teacher);
        } else {
            echo json_encode(["error" => "Teacher not found."]);
        }

        $stmt->close();
    } else {
        // Fetch all teachers
        $sql = "SELECT * FROM teachers";
        $result = $conn->query($sql);

        $teachers = [];
        while ($row = $result->fetch_assoc()) {
            $teachers[] = $row;
        }

        echo json_encode($teachers);
    }
}

// Update Teacher
function updateTeacher($conn, $data) {
    $id = $data['ID'] ?? null;
    $firstname = $data['FIRSTNAME'] ?? null;
    $middlename = $data['MIDDLENAME'] ?? null;
    $lastname = $data['LASTNAME'] ?? null;
    $birthdate = $data['BIRTHDATE'] ?? null;
    $address = $data['ADDRESS'] ?? null;
    $contact_number = $data['CONTACT_NUMBER'] ?? null;
    $picture = $data['PICTURE'] ?? null;
    $email = $data['EMAIL'] ?? null;

    if (!$id) {
        echo json_encode(["error" => "Teacher ID is required."]);
        return;
    }

    $sql = "UPDATE teachers 
            SET FIRSTNAME = ?, MIDDLENAME = ?, LASTNAME = ?, BIRTHDATE = ?, ADDRESS = ?, CONTACT_NUMBER = ?, PICTURE = ?, EMAIL = ? 
            WHERE ID = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('ssssssssi', $firstname, $middlename, $lastname, $birthdate, $address, $contact_number, $picture, $email, $id);

    if ($stmt->execute()) {
        echo json_encode(["success" => "Teacher updated successfully!"]);
    } else {
        echo json_encode(["error" => $stmt->error]);
    }

    $stmt->close();
}

// Delete Teacher
function deleteTeacher($conn, $data) {
    $id = $data['ID'] ?? null;

    if (!$id) {
        echo json_encode(["error" => "Teacher ID is required."]);
        return;
    }

    $sql = "DELETE FROM teachers WHERE ID = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('i', $id);

    if ($stmt->execute()) {
        echo json_encode(["success" => "Teacher deleted successfully!"]);
    } else {
        echo json_encode(["error" => $stmt->error]);
    }

    $stmt->close();
}
?>
