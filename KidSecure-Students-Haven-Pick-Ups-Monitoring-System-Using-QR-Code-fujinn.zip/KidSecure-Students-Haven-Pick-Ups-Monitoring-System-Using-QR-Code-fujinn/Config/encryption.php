<?php
define('ENCRYPTION_KEY', 'ABCD1234ABCSAWDAWDAWDASUBOMOTITIKOWDfhs...'); // Use a secure key here

// Encrypt function from uploaded image
function encrypt($data) {
    $key = ENCRYPTION_KEY;
    $ivLength = openssl_cipher_iv_length('AES-256-CBC');
    $iv = openssl_random_pseudo_bytes($ivLength); // Generate a random IV
    $encryptedData = openssl_encrypt($data, 'AES-256-CBC', $key, 0, $iv);
    return base64_encode($iv . $encryptedData); // Concatenate IV and encrypted data, then encode
}

// Decrypt function from uploaded image
function decrypt($encryptedData) {
    $key = ENCRYPTION_KEY;
    $encryptedData = base64_decode($encryptedData); // Decode the Base64-encoded data
    $ivLength = openssl_cipher_iv_length('AES-256-CBC');
    $iv = substr($encryptedData, 0, $ivLength); // Extract the IV
    $ciphertext = substr($encryptedData, $ivLength); // Extract the ciphertext
    return openssl_decrypt($ciphertext, 'AES-256-CBC', $key, 0, $iv);
}


?>