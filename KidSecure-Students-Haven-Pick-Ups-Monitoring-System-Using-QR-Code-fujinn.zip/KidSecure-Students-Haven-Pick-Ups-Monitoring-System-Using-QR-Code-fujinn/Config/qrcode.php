<?php


function getQRCodeImage($qrValue){
    // Generate a temporary file for the QR code image
    $tempFile = 'temp_qrcode.png';

    // Generate the QR code
    QRcode::png($qrValue, $tempFile);

    // Read the generated image and convert it to base64
    $imageData = file_get_contents($tempFile);
    $base64Image = base64_encode($imageData);

    // Output the base64 image (for testing purposes)

    // Optionally: delete the temporary image file after use
    unlink($tempFile);
    return $base64Image;
}

?>
