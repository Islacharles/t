<?php
session_start(); // Start the session
include '../../Config/connection.php';
include '../../Config/auth.php';

$_SESSION['header'] = 'Create Authorize Persons';
?>

<!DOCTYPE html>
<html>
<head>
    <title>New Authorize Personel</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="css/styles.css" rel="stylesheet" />
    <link href="create.css" rel="stylesheet" /> 
</head>
<body>
    <?php include '../shared/sidebar.php' ?>
    <div class="container-main">
        <div class="main-wrapper-body"> 
            <div class="container">
                <div class="row">
                    <div class="col-lg-3 col-md-4 col-sm-12">
                        <img src="" alt="" class="user-img" id="imgUser" name="frmGroup">
                        <small class="form-text text-danger" ident="imgUser" name="frmGroup"></small>
                        <button class="btn btn-dark upload-btn" id="btnUpload" style="margin-bottom: 16px;">Upload</button>
                        <input type="file" id="txtChooseFile" hidden accept=".jpg, .jpeg, .png">
                        <br/>
                    </div>
                    <div class="col-lg-9 col-md-8 col-sm-12">
                        <div class="form-group">
                            <label for="txtFirstName">First Name</label>
                            <input type="text" class="form-control" id="txtFirstName" name="frmGroup" aria-describedby="txtName" placeholder="Enter First Name">
                            <small ident="FirstName" name="frmGroup" class="form-text text-danger"></small>
                        </div>
                        <div class="form-group">
                            <label for="txtMiddleName">Middle Name</label>
                            <input type="text" class="form-control" id="txtMiddleName" name="frmGroup" aria-describedby="txtName" placeholder="Enter First Name">
                            <small ident="MiddleName" name="frmGroup" class="form-text text-danger"></small>
                        </div>
                        <div class="form-group">
                            <label for="txtLastName">Last Name</label>
                            <input type="text" class="form-control" id="txtLastName" name="frmGroup" aria-describedby="txtName" placeholder="Enter First Name">
                            <small ident="LastName" name="frmGroup" class="form-text text-danger"></small>
                        </div>
                        <div class="form-group">
                            <label for="txtContactNumber">Contact Number</label>
                            <input type="text" class="form-control" id="txtContactNumber" name="frmGroup" aria-describedby="txtName" placeholder="Enter First Name">
                            <small ident="ContactNumber" name="frmGroup" class="form-text text-danger"></small>
                        </div>
                        <div class="form-group">
                            <label for="txtAddress">Address</label>
                            <textarea name="" id="txtAddress" class="form-control"></textarea>
                            <small ident="Address" name="frmGroup" class="form-text text-danger"></small>
                        </div>
                        <br>
                        <hr>
                        <br>
                        <div class="action">
                            <a type="button" href="index.php" class="btn btn-secondary">Cancel</a>
                            <button class="btn btn-primary" id="btnSubmit">Submit</button>
                        </div>
                        <br>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script>
    let imageBase64 = '';
    $(document).ready(function(){
        $("#imgUser").attr('src','../../assets/empty-user.png') 
    })

    $("#btnUpload").on('click', function(){
        $("#txtChooseFile").click();
    });
    
    $("#btnGuardianUpload").on('click', function(){
        $("#txtGuardianChooseFile").click();
    });

    $("#txtChooseFile").on('change', function(){
        const file = event.target.files[0];
        imageBase64 = "";
        const validExtensions = ["image/jpeg","image/jpg", "image/png"]; // Allowed MIME types

        if (file && validExtensions.includes(file.type)) {
            // Clear any previous error
            // $("#error").hide();

            // Display the selected image in the <img> tag
            const reader = new FileReader();
            reader.onload = function (e) {
                $("#imgUser").attr("src", e.target.result);
                var base64String = reader.result.split(',')[1];
                imageBase64 = base64String;
            };
            reader.readAsDataURL(file);
        } else {
            // Show an error if the file is invalid
            // $("#error").text("Please select a valid JPEG or PNG image.").show();
            // $("#preview").hide();
            $("#txtChooseFile").val("")
        }
    })


    $("#btnSubmit").on("click", function(){
    if (!imageBase64) { // Check if imageBase64 is empty (i.e., no image uploaded)
        alert("Please upload a picture.");
        return; // Prevent form submission if no image is uploaded
    }

    if (!confirm("Do you really want to submit?")) {
        return;
    }

        let formData = new FormData();
        formData.append("FirstName", $("#txtFirstName").val());
        formData.append("MiddleName", $("#txtMiddleName").val());
        formData.append("LastName", $("#txtLastName").val());
        formData.append("ContactNumber", $("#txtContactNumber").val());
        formData.append("ParentID", $("#txtSection").val());
        formData.append("Address", $("#txtAddress").val()); 
        formData.append("ParentID", <?=$_SESSION['id']?>); 
        formData.append("PictureBase64", imageBase64); 

        clearErrorsForm();
         // Make AJAX POST request
        $.ajax({
            url: 'create-api.php', // Replace with your server endpoint
            type: 'POST',
            data: formData,
            processData: false, // Prevent jQuery from automatically transforming the data
            contentType: false, // Let the browser set the content type, including the boundary
            success: function (response) {
                // Parse JSON response and display it
                console.log(response)
                if(response?.status !== 'error'){
                    alert(response?.message);
                    window.location.href = "index.php";
                }
                // Loop through JSON object and get field names
                $.each(response.message, function(fieldName, fieldValue) {
                    console.log("Field Name: " + fieldName , fieldValue); // Logs the field name (key)
                    fieldValue?.forEach(element => {
                        console.log(fieldName, element)
                        $(`#txt${fieldName}`).addClass("is-invalid");
                        $(`small[ident='${fieldName}']`).append(element + "<br/>");
                        $(`img[id='${fieldName}']`).attr("Style","border:1px solid red;");
                    });
                });
                
            },
            error: function (xhr) {
            // Display error message
            let errorResponse = JSON.parse(xhr.responseText);
            if (errorResponse?.error) {
                // Display general error at the top or in a specific container
                alert(errorResponse.error); // Alert the user
                $("#general-error").text(errorResponse.error).css("color", "red").show();
            }
        }
        });
    })

    $("#btnCancel").on('click', function(){
        clearErrorsForm();
    })

    function clearErrorsForm(){
        $("input[name='frmGroup']").removeClass("is-invalid");
        $("select[name='frmGroup']").removeClass("is-invalid");
        $("textarea[name='frmGroup']").removeClass("is-invalid");
        $("small[name='frmGroup']").html("");
        $(`img[name='frmGroup']`).attr("Style","");
    }
</script>
</body>
</html>
