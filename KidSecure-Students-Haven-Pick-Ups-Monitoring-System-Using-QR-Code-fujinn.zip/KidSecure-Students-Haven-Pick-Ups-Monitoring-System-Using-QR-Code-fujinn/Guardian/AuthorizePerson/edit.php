<?php
session_start(); // Start the session
include '../../Config/connection.php';
include '../../Config/auth.php';

if(!isset($_GET['id'])){
    header("Location: index.php");
}

$id = $_GET['id'] ;

// Validate the ID
if (empty($id)) {
    header("Location: index.php");
    exit();
}

if (!ctype_digit($id)) {
    header("Location: index.php");
    exit();
}

include '../../Config/connection.php'; // Database connection

// Prepare the SQL query to get the authorized personnel by ID
$sql = "SELECT ID, FIRSTNAME, MIDDLENAME, LASTNAME, CONTACT_NUMBER, ADDRESS, PARENT_ID, PICTURE 
        FROM authorize_person 
        WHERE ID = ?";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id); // Bind the ID as an integer
$stmt->execute();

$result = $stmt->get_result();

// Check if the record exists
if ($result->num_rows === 0) {
    header("Location: index.php");
} else {
    // Fetch the record
    $person = $result->fetch_assoc();
}

$_SESSION['header'] = 'Edit Authorize Persons';
?>

<!DOCTYPE html>
<html>
<head>
    <title>New Authorize Personel</title>
    <link href="css/styles.css" rel="stylesheet" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="create.css" rel="stylesheet" /> 
</head>
<body>
    <?php include '../shared/sidebar.php' ?>
    <div class="container-main">
        <div class="main-wrapper-body"> 
            <div class="container">
                <div class="row">
                    <div class="col-lg-3 col-md-4 col-sm-12">
                        <img src="data:image/png;base64,<?=$person['PICTURE']?>" alt="" class="user-img" id="imgUser">
                        <button class="btn btn-dark upload-btn" id="btnUpload" style="margin-bottom: 16px;">Upload</button>
                        <input type="file" id="txtChooseFile" hidden accept=".jpg, .jpeg, .png">
                    </div>
                    <div class="col-lg-9 col-md-8 col-sm-12">
                        <div class="form-group">
                            <label for="txtFirstName">First Name</label>
                            <input type="text" class="form-control" value="<?=$person['FIRSTNAME']?>" id="txtFirstName" name="frmGroup" aria-describedby="txtName" placeholder="Enter First Name">
                            <small ident="FirstName" name="frmGroup" class="form-text text-danger"></small>
                        </div>
                        <div class="form-group">
                            <label for="txtMiddleName">Middle Name</label>
                            <input type="text" class="form-control" value="<?=$person['MIDDLENAME']?>" id="txtMiddleName" name="frmGroup" aria-describedby="txtName" placeholder="Enter First Name">
                            <small ident="MiddleName" name="frmGroup" class="form-text text-danger"></small>
                        </div>
                        <div class="form-group">
                            <label for="txtLastName">Last Name</label>
                            <input type="text" class="form-control" value="<?=$person['LASTNAME']?>" id="txtLastName" name="frmGroup" aria-describedby="txtName" placeholder="Enter First Name">
                            <small ident="LastName" name="frmGroup" class="form-text text-danger"></small>
                        </div>
                        <div class="form-group">
                            <label for="txtContactNumber">Contact Number</label>
                            <input type="number" class="form-control" id="txtContactNumber" value="<?=$person['CONTACT_NUMBER']?>" name="frmGroup" aria-describedby="txtName" placeholder="Enter First Name">
                            <small ident="ContactNumber" name="frmGroup" class="form-text text-danger"></small>
                        </div>
                        <div class="form-group">
                            <label for="txtAddress">Address</label>
                            <textarea name="" id="txtAddress" class="form-control"><?=$person['ADDRESS']?></textarea>
                            <small ident="Address" name="frmGroup" class="form-text text-danger"></small>
                        </div>
                        <br>
                        <hr>
                        <br>
                        <div class="action">
                            <a type="button" href="index.php" class="btn btn-secondary">Cancel</a>
                            <button class="btn btn-primary" id="btnSubmit">Submit</button>
                        </div>
                        <br>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script>
    let imageBase64 = '<?=$person['PICTURE']?>';

    $("#btnUpload").on('click', function(){
        $("#txtChooseFile").click();
    });
    
    $("#btnGuardianUpload").on('click', function(){
        $("#txtGuardianChooseFile").click();
    });

    $("#txtChooseFile").on('change', function(){
        const file = event.target.files[0];
        imageBase64 = "";
        const validExtensions = ["image/jpeg","image/jpg", "image/png"]; // Allowed MIME types

        if (file && validExtensions.includes(file.type)) {
            // Clear any previous error
            // $("#error").hide();

            // Display the selected image in the <img> tag
            const reader = new FileReader();
            reader.onload = function (e) {
                $("#imgUser").attr("src", e.target.result);
                var base64String = reader.result.split(',')[1];
                imageBase64 = base64String;
            };
            reader.readAsDataURL(file);
        } else {
            // Show an error if the file is invalid
            // $("#error").text("Please select a valid JPEG or PNG image.").show();
            // $("#preview").hide();
            $("#txtChooseFile").val("")
        }
    })


    $("#btnSubmit").on("click", function(){

        if(!confirm("Do you really want to submit?")){
            return;
        }

        let formData = new FormData();
        formData.append("AuthorizeID", "<?=$id?>");
        formData.append("FirstName", $("#txtFirstName").val());
        formData.append("MiddleName", $("#txtMiddleName").val());
        formData.append("LastName", $("#txtLastName").val());
        formData.append("ContactNumber", $("#txtContactNumber").val());
        formData.append("ParentID", $("#txtSection").val());
        formData.append("Address", $("#txtAddress").val()); 
        formData.append("ParentID", <?=$_SESSION['id']?>); 
        formData.append("PictureBase64", imageBase64); 

        clearErrorsForm();
         // Make AJAX POST request
        $.ajax({
            url: 'edit-api.php', // Replace with your server endpoint
            type: 'POST',
            data: formData,
            processData: false, // Prevent jQuery from automatically transforming the data
            contentType: false, // Let the browser set the content type, including the boundary
            success: function (response) {
                // Parse JSON response and display it
                console.log(response)
                if(response?.status !== 'error'){
                    alert(response?.message);
                    window.location.href = "index.php";
                }
                // Loop through JSON object and get field names
                $.each(response.message, function(fieldName, fieldValue) {
                    console.log("Field Name: " + fieldName , fieldValue); // Logs the field name (key)
                    fieldValue?.forEach(element => {
                        console.log(fieldName, element)
                        $(`#txt${fieldName}`).addClass("is-invalid");
                        $(`small[ident='${fieldName}']`).append(element + "<br/>");
                    });
                });
                
            },
            error: function (xhr, status, error) {
                // Handle error
                console.log(error)
            }
        });
    })

    $("#btnCancel").on('click', function(){
        clearErrorsForm();
    })

    function clearErrorsForm(){
        $("input[name='frmGroup']").removeClass("is-invalid");
        $("select[name='frmGroup']").removeClass("is-invalid");
        $("textarea[name='frmGroup']").removeClass("is-invalid");
        $("small[name='frmGroup']").html("");
    }
</script>
</body>
</html>
