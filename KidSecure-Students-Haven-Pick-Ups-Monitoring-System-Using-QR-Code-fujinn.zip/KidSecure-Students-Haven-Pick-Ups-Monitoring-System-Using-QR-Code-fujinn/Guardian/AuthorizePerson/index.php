<?php
session_start(); // Start the session
include '../../Config/connection.php';
include '../../Config/auth.php';
$_SESSION['header'] = 'Authorize Persons';
?>

<!DOCTYPE html>
<html>
<head>
    <title>Student Records</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="index.css" rel="stylesheet" />
    <title>Student Records</title>
</head>
<body>
    <?php include '../shared/sidebar.php' ?>
    <div class="container-main container ">
        <div class="card-container">
            <div class="row"> 
                <div class="col-lg-12 col-md-12 col-sm-12">
                    <div class="search-field col-12" style="display: flex;"> 
                        <input type="text" id="searchField" class="form-control form-control-sm" placeholder="Search Students..."> 
                        <a type="button" href="create.php" class="btn btn-primary btn-block">Create</a>
                        <button type="button" class="btn btn-danger" style="margin-left: 10px;" id="viewArchived" data-bs-toggle="modal" data-bs-target="#archivedModal"> View Archived </button>
                    </div>
                    <hr>
                    <br>
                    <div class="container">
                        <div class="row" id="card-list">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="archivedModal" tabindex="-1" aria-labelledby="archivedModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="archivedModalLabel">Archived Students</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <table class="table table-bordered table-hover align-middle" id="ArchivedTable">
                    <thead class="table-dark">
                        <tr>
                            <th>Picture</th>
                            <th>Full Name</th>
                            <th>Contact Number</th>
                            <th>Address</th>
                        </tr>
                    </thead>
                    <tbody></tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<script>
    $(document).ready(function(){
        searchData();
    })

    $("#searchField").on('keyup', function() {
            // Clear the previous timer (if any)
        // searchData($("#searchField").val());
        searchData($("#searchField").val());
    });

    function searchData(search = ''){
        $("#card-list").html('');
            // Make the AJAX GET request with parameters
        $.ajax({
            url: 'index-search-api.php',  // Replace with your PHP script file
            type: 'GET',
            data: { search: search, parentId : "<?=$_SESSION['id']?>" },  // Send parameters in the query string
            success: function(response) {
                // Handle the response (e.g., display in a div)
                console.log(response);
                response?.forEach(obj => {
                    $("#card-list").append(`
                        <div class="col-lg-3 col-md-4 col-sm-6">
                            <div class="card-body">
                                <img src="data:image/png;base64,${obj.picture}" alt="">
                                <div class="details">
                                    <p>${obj.fullname}</p>
                                    <small>${obj.contact_number}</small>
                                </div>
                                <div class="action">
                                    <a type="button" href="edit.php?id=${obj.id}" class="btn btn-dark">Edit</a>
                                    <button ident="${obj.id}" name="btnArchive" class="btn btn-danger">Archive</button>
                                </div>
                            </div>
                        </div>
                    `)
                });
            },
            error: function(xhr, status, error) {
                // Handle error
                console.log("An error occurred: " + error);
            }
        });
    }

    $(document).on("click", "button[name='btnArchive']", function() {
        var id = $(this).attr('ident');
        if (confirm("Are you sure you want to archive this authorized person?")) {
            $.ajax({
                url: "delete-api.php",  // PHP script that performs the archiving
                type: "POST",
                data: { id: id },
                success: function(response) {
                location.reload(); 
                alert (response.message)
                },
                error: function(xhr, status, error) {
                    alert("An error occurred: " + error);
                }
            });
        }
    });
    $(document).ready(function () {
                const archivedTable = $('#ArchivedTable').DataTable({
                    ajax: {
                        url: 'fetch-archived-authorize-api.php',
                        type: 'GET',
                        dataSrc: ''
                    },
                    columns: [
                    {
                        data: 'picture',
                        render: function (data) {
                            return `<img src="data:image/png;base64,${data.picture}" class="table-img" alt="N/A">`;
                        }
                    },
                    { data: 'fullname' },
                    { data: 'contact_number' },
                    { data: 'address' }
                    ]
                });
            });

</script>
</body>
</html>
