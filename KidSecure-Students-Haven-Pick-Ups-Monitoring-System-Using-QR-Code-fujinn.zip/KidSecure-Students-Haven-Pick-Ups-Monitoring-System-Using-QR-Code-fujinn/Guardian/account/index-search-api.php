<?php
include '../../Config/connection.php'; // Database connection


$parentID = $_SESSION['parentID']; 

$sql = "SELECT  
            ID, 
            FIRSTNAME, 
            MIDDLENAME, 
            LASTNAME, 
            CONTACT_NUMBER, 
            ADDRESS, 
            EMAIL, 
            PICTURE 
        FROM 
            guardian 
        WHERE 
            ID = ?"; 
$stmt->bind_param("i", $parentID);  
$stmt->execute();
$result = $stmt->get_result();

// Prepare response
$data = [];
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $data = [
        'fullname' => $row['FIRSTNAME'] . ' ' . $row['MIDDLENAME'] . ' ' . $row['LASTNAME'],
        'contact_number' => $row['CONTACT_NUMBER'],
        'address' => $row['ADDRESS'],
        'email' => $row['EMAIL'],
        'picture' => $row['PICTURE'] ? $row['PICTURE'] : 'pic/default_image.jpg', 
    ];
}

echo json_encode($data);
$stmt->close();
$conn->close();
?>