
<?php
    header('Location: events/')
?>