<?php
include '../../Config/api-config.php';  // Include database connection settings
include '../../Config/connection.php'; // Include connection to MySQL

// Get user_id (in this case, parent_id) from request parameters (can be from GET or POST)
$userId = $_GET['user_id'] ?? '';  // Assuming you send the user_id as a GET parameter

// Check if user_id is provided
if (empty($userId)) {
    echo json_encode(['status' => 'error', 'message' => 'User ID is required.']);
    exit();
}

// SQL query to retrieve notifications for the specific user
$sql = "SELECT 
    n.ID, 
    n.USER_ID, 
    n.TITLE, 
    n.REDIRECTION, 
    n.DESCRIPTION, 
    n.CREATED_DT, 
    n.STUDENT_ID, 
    n.IS_READ,
    s.FIRSTNAME AS student_firstname,
    s.LASTNAME AS student_lastname,
    s.GRADE_LEVEL,
    s.SECTION,
    g.FIRSTNAME AS parent_firstname,
    g.LASTNAME AS parent_lastname,
    g.CONTACT_NUMBER AS parent_contact,
    g.EMAIL AS parent_email,
    s.PICTURE
FROM 
    notifications n
INNER JOIN 
    students s ON n.STUDENT_ID = s.ID  -- Join the students table
INNER JOIN 
    guardian g ON n.USER_ID = g.ID   -- Join the guardian (parent) table
WHERE 
    n.USER_ID = ? 
ORDER BY 
    n.CREATED_DT DESC"; // Order notifications by creation date (newest first)

// Prepare the statement
$stmt = $conn->prepare($sql);

// Check for errors in the prepared statement
if (!$stmt) {
    echo json_encode(['status' => 'error', 'message' => 'Error preparing query: ' . $conn->error]);
    exit();
}

// Bind parameters and execute the query
$stmt->bind_param("i", $userId);
$stmt->execute();

// Get the result
$result = $stmt->get_result();

// Initialize an array to hold notifications
$notifications = [];

// Fetch all the notifications for the user
while ($row = $result->fetch_assoc()) {
    $notifications[] = $row;
}

// If no notifications found
if (empty($notifications)) {
    echo json_encode(['status' => 'success', 'message' => 'No notifications found.']);
} else {
    // Return notifications as JSON
    echo json_encode(['status' => 'success', 'data' => $notifications]);
}

// Close the statement and the connection
$stmt->close();
$conn->close();
?>
