<?php
include '../../Config/api-config.php'; // Database configuration
include '../../Config/connection.php'; // Open database connection

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['status' => 'error', 'message' => 'Invalid request method.']);
    exit();
}

// Get notification ID from POST data
$notificationId = $_POST['notification_id'] ?? '';

// Validate the notification ID
if (empty($notificationId)) {
    echo json_encode(['status' => 'error', 'message' => 'Notification ID is required.']);
    exit();
}

// SQL query to update the IS_READ field
$sql = "UPDATE notifications SET IS_READ = b'1' WHERE ID = ?";

// Prepare the statement
$stmt = $conn->prepare($sql);

// Bind the notification ID parameter
$stmt->bind_param("i", $notificationId);

// Execute the query
if ($stmt->execute()) {
    echo json_encode(['status' => 'success', 'message' => 'Notification marked as read.']);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Failed to update notification status.']);
}

// Close the statement and the connection
$stmt->close();
$conn->close();
?>
