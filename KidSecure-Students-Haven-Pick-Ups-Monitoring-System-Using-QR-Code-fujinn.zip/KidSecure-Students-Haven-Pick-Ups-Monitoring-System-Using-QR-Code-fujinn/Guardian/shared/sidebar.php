
<?php 
    include '../../Config/auth.php';
    include '../../Config/jslib.php';
    
    function getIsActiveClass($cls){  
        if (str_contains($_SERVER['REQUEST_URI'], $cls)) {
            return "active";
        } else {
            return "";
        }
    }
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['profile_image'])) {
        // Process the image upload
        $image = $_FILES['profile_image'];
        $imageData = base64_encode(file_get_contents($image['tmp_name'])); // Get base64 of the uploaded image

        // Save the image to the database (You should implement this in your database update logic)
        // For example, assume the updated image is saved in $newImageData
        $newImageData = $imageData; // Replace with your actual database logic to fetch the updated picture

        // Update session with the new image
        $_SESSION['picture'] = $newImageData;

        // Redirect to avoid resubmitting the form on page refresh
        header('Location: ' . $_SERVER['PHP_SELF']);
        exit();
    }
?>
<link href="../shared/sidebars.css" rel="stylesheet" />
<div class="sidebar" id="sidebar">
    <img src="../../Admin/logo/logo/logo.png" alt="Logo"> 
    <a href="../events" class="<?=getIsActiveClass("events")?>">
        <i class="fas fa-calendar-alt"></i> Events
    </a>
    <a href="../announcement" class="<?=getIsActiveClass("announcement")?>">
        <i class="fas fa-bullhorn"></i> Announcements
    </a>
    <a href="../authorizeperson" class="<?=getIsActiveClass("authorizeperson")?>">
        <i class="fas fa-user-graduate"></i> Authorize Persons
    </a>
    <a href="../student" class="<?=getIsActiveClass("student")?>">
        <i class="fas fa-child"></i> Child
    </a>
    <a href="../account" class="<?=getIsActiveClass("account")?>">
        <i class="fas fa-users"></i> My Account
    </a>
    
    <div class="bottom-links">
    <a href="javascript:void(0);" onclick="confirmLogout();">
        <i class="fas fa-sign-out-alt"></i> Logout
    </a>
    </div>

    <script>
        function confirmLogout() {
            // Show confirmation dialog
            if (confirm("Are you sure you want to log out?")) {
                // Redirect to logout.php if confirmed
                window.location.href = "../../logout.php";
            }
        }
    </script>
    </div>
</div>

<div class="main-body-container" id="main-body-container">
    <div class="main-header">
        <h2 class="fw-bold"><small id="btnHumberger">☰</small> &nbsp; <?=($_SESSION['header'] ?? '')?></h2>
        <div class="profile">
            <div class="btn-notif-wrapper">
                <small id="notif-count">0</small>
                <i class="fas fa-envelope btnNotif" id="btnNotif"></i>
            </div>
            <img alt="User profile picture" height="40" src="data:image/png;base64,<?=$_SESSION['picture']?>" width="40"/>
            <div class="profile-text">
                <p><?=$_SESSION['fullname']?></p>
                <small><?=$_SESSION['role']?></small>
            </div>
        </div>
        <div class="notification-body bg-primary" id="notification-body" style="display:none;">
            <div class="head-component">
                <h4>Notifications</h4>
            </div> 
            <div class="notif-list">
                <ul id="notif-list">
                </ul>
            </div> 
        </div>
    </div>



<script>

    $(document).ready(function(){
        fetchNotificationData();
        if ($(window).width() < 575){
            $('#sidebar').addClass("sidebar-hide");
            $('#main-body-container').addClass("main-body-container-min");
        }
    });

    $("#btnNotif").on('click', function(){ 
        if($("#notification-body").css("display") !== "none"){
            $("#notification-body").hide();
        }else{
            $("#notification-body").show();
        }
    })

    function fetchNotificationData(){
        $.ajax({
            url: '../shared/get-notification-api.php', // The PHP script that will handle the request
            type: 'GET',
            data: {
                user_id: <?=$_SESSION['id']?>
            },
            success: function(response) { 
                console.log(response.data); 
                $("#notif-list").html('');
                $("#notif-count").html(response.data?.filter(x => !x.IS_READ).length ?? 0 )
                if(!response.data?.filter(x => !x.IS_READ).length){
                    $("#notif-count").hide();
                }
                response.data?.forEach(obj => {
                    $("#notif-list").append(`
                        <li class="${obj.IS_READ ? '' : 'unread'}" name="notif-item" redirect="${obj.REDIRECTION}" ident="${obj.ID}">
                            <img class="notifImg" src="data:image/png;base64,${obj.PICTURE}" alt="">
                            <div class="notif-details">
                                <label>${obj.student_firstname} ${obj.student_lastname}</label>
                                <p>${obj.DESCRIPTION}</p>
                                <small>${obj.CREATED_DT}</small>
                            </div>
                        </li>
                    `)
                });
            },
            error: function(xhr, status, error) { 
                console.log(error);
            }
        });
    }

    $(document).on('click', 'li[name="notif-item"]', function(){
        const rd = $(this).attr('redirect');
        const ident = $(this).attr('ident');
        $.ajax({
            url: '../shared/notif-read-api.php', // The PHP script that will handle the request
            type: 'POST',
            data: {
                notification_id: ident
            },
            success: function(response) { 
                console.log(response.data); 
                window.location.href = rd;
            },
            error: function(xhr, status, error) { 
                console.log(error);
            }
        });
    })

    $("#btnHumberger").on('click', function(){
        if($("#sidebar").hasClass("sidebar-hide")){ 
            $('#sidebar').removeClass("sidebar-hide");
            $('#main-body-container').removeClass("main-body-container-min");
        }else{ 
            $('#sidebar').addClass("sidebar-hide");
            $('#main-body-container').addClass("main-body-container-min");
        }
    })
</script>

<!-- 
<div class="main-content">
    <div class="header">
        <div class="user-info">
            <div class="notification">
                <i class="fas fa-bell"></i>
            </div>
            <div class="vertical-rule"></div>
            <div class="profile"> 
                <?php if (empty($profile_image)) : ?>
                    <img alt="User profile picture" height="40" src="<?php echo htmlspecialchars($profile_image); ?>" width="40"/>
                <?php else: ?>
                    <img alt="User profile picture" height="40" src="data:image/jpeg;base64,<?php echo base64_encode($profile_image); ?>" width="40"/>
                <?php endif; ?>
                <div class="profile-text">
                    <span><?php echo htmlspecialchars($_SESSION['role']); ?></span><br>
                    <span><?php echo htmlspecialchars($_SESSION['fullname']); ?></span>
                </div>
            </div>
        </div>
    </div>
    <hr/>
</div> 
-->