<?php
require '../../vendor/autoload.php'; // Load PhpSpreadsheet library
include '../../Config/connection.php';

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\Border;
use PhpOffice\PhpSpreadsheet\Style\Fill;

// Function to generate and export attendance report
function reportAttendance($date) {
    global $conn; // Use global $conn for database connection

    // Prepare SQL to fetch attendance data
        $query = $conn->prepare("
        SELECT 
            sa.student_id AS student_number, 
            CONCAT(s.FIRSTNAME, ' ', s.LASTNAME) AS student_name, 
            s.GRADE_LEVEL AS grade_level, 
            s.SECTION AS section, 
            sa.CREATED_DT AS created_date, 
            sa.TIME_IN AS time_in, 
            sa.TIME_OUT AS time_out, 
            CONCAT(ap.FIRSTNAME, ' ', ap.LASTNAME) AS authorize_fullname
        FROM 
            student_attendance sa
        JOIN 
            students s ON sa.student_id = s.id
        LEFT JOIN 
            (
                SELECT 
                    ID, 
                    FIRSTNAME, 
                    LASTNAME 
                FROM 
                    authorize_person 
                UNION 
                SELECT 
                    ID, 
                    FIRSTNAME, 
                    LASTNAME 
                FROM 
                    guardian
            ) ap 
        ON 
            sa.AUTHORIZE_ID = ap.ID
        WHERE 
            sa.CREATED_DT = ? 
        ORDER BY 
            s.GRADE_LEVEL ASC, s.SECTION ASC
    ");

    $query->bind_param('s', $date);
    $query->execute();
    $result = $query->get_result();


    // Check if any data exists
    if ($result->num_rows === 0) {
        header('HTTP/1.1 404 Not Found');
        echo 'No data found for the selected date.';
        exit();
    }

    // Initialize Spreadsheet
    $spreadsheet = new Spreadsheet();
    $sheet = $spreadsheet->getActiveSheet();

    // Set up Excel headers
    $sheet->setCellValue('A1', 'Attendance Report');
    $sheet->setCellValue('A2', 'Date: ' . $date);
    $sheet->mergeCells('A1:H1');
    $sheet->mergeCells('A2:H2');
    $sheet->getStyle('A1')->getFont()->setBold(true)->setSize(16);
    $sheet->getStyle('A2')->getFont()->setSize(12);
    $sheet->getStyle('A1:H2')->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);

    // Add table headers
    $headers = ['Student #', 'Full Name', 'Grade Level', 'Section', 'Date', 'Time In', 'Time Out', 'Authorize Person'];
    $column = 'A';
    foreach ($headers as $header) {
        $sheet->setCellValue($column . '4', $header);
        $sheet->getStyle($column . '4')->getFont()->setBold(true);
        $sheet->getStyle($column . '4')->getBorders()->getAllBorders()->setBorderStyle(Border::BORDER_MEDIUM);
        $sheet->getStyle($column . '4')->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
        $column++;
    }

    // Populate data rows
    $row = 5;
    while ($data = $result->fetch_assoc()) {
        $sheet->setCellValue('A' . $row, $data['student_number']);
        $sheet->setCellValue('B' . $row, $data['student_name']);
        $sheet->setCellValue('C' . $row, $data['grade_level']);
        $sheet->setCellValue('D' . $row, $data['section']);
        $sheet->setCellValue('E' . $row, $data['created_date']);
        $sheet->setCellValue('F' . $row, $data['time_in']);
        $sheet->setCellValue('G' . $row, $data['time_out']);
        $sheet->setCellValue('H' . $row, $data['authorize_fullname']);
        $row++;
    }

    // Adjust column widths
    foreach (range('A', 'H') as $col) {
        $sheet->getColumnDimension($col)->setAutoSize(true);
    }

    // Send file as download
    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    header('Content-Disposition: attachment; filename="Child_Attendance_Report.xlsx"');
    header('Cache-Control: max-age=0');

    $writer = new Xlsx($spreadsheet);
    $writer->save('php://output');
    exit();
}

// Get date from POST request and call the function
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $date = $_POST['date'] ?? null;

    if (!$date) {
        header('HTTP/1.1 400 Bad Request');
        echo 'Error: Date is required.';
        exit();
    }

    reportAttendance($date);
}
?>
