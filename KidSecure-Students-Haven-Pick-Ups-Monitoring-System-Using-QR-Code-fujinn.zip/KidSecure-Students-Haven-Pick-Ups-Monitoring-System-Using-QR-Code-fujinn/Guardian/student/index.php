<?php
session_start(); // Start the session
include '../../Config/connection.php';
include '../../Config/auth.php';
$_SESSION['header'] = 'Child';
?>

<!DOCTYPE html>
<html>
<head>
    <title>Student Records</title>
    <link href="css/styles.css" rel="stylesheet" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="index.css" rel="stylesheet" /> 
</head>
<body>
    <?php include '../shared/sidebar.php' ?>
    <div class="container-main">
    <div class="main-wrapper-body card-container">
        <div class="row">
            <div class="col-md-12">
                <div class="search-field" style="display: flex;"> 
                    <input type="text" id="searchField" class="form-control" placeholder="Search Students..." onkeyup="searchTable()"> 
                </div>
                <br>
            </div>
            <div class="col-12 row" id="student-content">
                <!-- Student cards will be appended here -->
            </div>
        </div>
    </div>
    <div class="main-wrapper-body card-container">
        <h3 class="fw-bold">Attendance</h3>
        <hr>
        <div class="table-container">
            <div class="row mb-4">
                <!-- Move the container to the far right using ml-auto -->
                <div class="col-md-7">
                    <!-- Empty space on the left if needed, or can be left blank -->
                </div>
              
                <div class="row mb-4">
                    <div class="col-md-4">
                        <label for="fromDate" class="form-label">From Date:</label>
                        <input type="date" id="fromDate" class="form-control">
                    </div>
                    <div class="col-md-4">
                        <label for="toDate" class="form-label">To Date:</label>
                        <input type="date" id="toDate" class="form-control">
                    </div>
                </div>
            </div>
            <table class="table table-striped table-bordered" id="attendanceTable">
                <thead class="table-dark">
                    <tr>
                        <th>Student #</th>
                        <th>Full Name</th>
                        <th>Grade Level</th>
                        <th>Section</th>
                        <th>Date</th>
                        <th>Time In</th>
                        <th>Time Out</th>
                        <th>Authorize Person</th>
                    </tr>
                </thead>
                <tbody id="body-table">
                    <!-- Attendance data will be appended here -->
                </tbody>
            </table>
        </div>
    </div>
</div>

    <script>
    $(document).ready(function () {
        // Initialize DataTable with column search inputs
        var table = $('#attendanceTable').DataTable({
            dom: '<"row"<"col-md-6"l><"col-md-6 text-end"Bf>>rtip',  // This defines the layout for DataTable buttons
            buttons: ['copy', 'csv', 'excel', 'pdf', 'print'], // Adding buttons for export and print
            initComplete: function () {
                // Add custom search inputs for each column in the table
                this.api().columns().every(function () {
                    var column = this;
                    var input = $('<input type="text" placeholder="Search...">')
                        .appendTo($(column.footer()).empty()) // Append to column footer
                        .on('keyup change', function () {
                            column.search($(this).val()).draw(); // Apply column-specific search
                        });
                });
            }
        });

        var today = new Date();
        var yyyy = today.getFullYear();
        var mm = today.getMonth() + 1; // Months are zero-based
        var dd = today.getDate();

        if (mm < 10) mm = '0' + mm;
        if (dd < 10) dd = '0' + dd;

        var formattedDate = yyyy + '-' + mm + '-' + dd;
        $('#fromDate').val(formattedDate);
        $('#toDate').val(formattedDate);

        fetchData();
        

        // Trigger data fetching on filter changes
        $("#fromDate, #toDate, #searchStudent").on('input', function () {
        fetchData();
        });
        // Fetch attendance data
        function fetchData() {
            var search = "<?=$_SESSION['id']?>";
            var fromDate = $('#fromDate').val();
            var toDate = $('#toDate').val();

            // AJAX GET request
            $.ajax({
                url: 'search-attendance-api.php', // API URL
                method: 'GET',
                data: {
                    search: search,
                    fromDate: fromDate,
                    toDate: toDate
                },
                success: function (response) {
                    table.clear(); // Clear existing table data
                    response?.forEach(function (item) {
                        table.row.add([
                            item.student_number,
                            item.student_name,
                            item.grade_level,
                            item.section,
                            item.created_date,
                            item.time_in,
                            item.time_out,
                            item.authorize_fullname
                        ]);
                    });
                    table.draw(); // Redraw the table with new data

                    // Apply date filter (filter by created_date column)
                    table.column(4).search(date).draw(); // Assuming 'created_date' is the 5th column
                },
                error: function () {
                    alert('An error occurred while fetching the data.');
                }
            });
        }

        // Fetch and display student data
        function searchData(search = '') {
            $("#student-content").html(''); // Clear existing content

            $.ajax({
                url: 'index-search-api.php', // API URL
                type: 'GET',
                data: {
                    search: search,
                    guardianId: "<?=$_SESSION['id']?>"
                },
                success: function (response) {
                    response?.forEach(obj => {
                        $("#student-content").append(`
                            <div class="col-lg-3 col-md-4 col-sm-6">
                                <div class="card-body">
                                    <img src="data:image/png;base64,${obj.picture}" alt="Student Picture">
                                    <div class="details">
                                        <p>${obj.student_name}</p>
                                        <small>${obj.grade_level}</small>
                                    </div>
                                    <div class="action">
                                        <a type="button" href="view.php?id=${obj.student_number}" ident="${obj.student_number}" class="btn btn-primary">View</a>
                                    </div>
                                </div>
                            </div> 
                        `);
                    });
                },
                error: function (xhr, status, error) {
                    console.log("An error occurred: " + error);
                }
            });
        }
    });
</script>


</body>
</html>