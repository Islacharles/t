<?php
session_start(); // Start the session
include '../../Config/connection.php';
require_once '../../library/phpqrcode/qrlib.php'; 
include '../../Config/qrcode.php';

if(!isset($_GET['id'])){
    header("Location: index.php");
}

$studentId = $_GET['id'] ;


// SQL Query to select all data using JOINs
$sql = "SELECT 
            s.ID AS student_number, 
            s.FIRSTNAME AS student_first_name, 
            s.LASTNAME AS student_last_name, 
            s.MIDDLENAME AS student_middle_name, 
            s.ADDRESS AS student_address, 
            s.BIRTHDATE AS student_birthdate, 
            s.PICTURE AS student_picture, 
            s.GRADE_LEVEL AS student_grade_level, 
            s.SECTION AS student_section,
            g.ID AS guardian_id,
            g.FIRSTNAME AS guardian_first_name, 
            g.LASTNAME AS guardian_last_name, 
            g.MIDDLENAME AS guardian_middle_name, 
            g.CONTACT_NUMBER AS guardian_contact, 
            g.ADDRESS AS guardian_address, 
            g.PICTURE AS guardian_picture, 
            g.EMAIL AS guardian_email 
        FROM students s
        INNER JOIN student_guardian sg ON s.ID = sg.STUDENT_NUMBER
        INNER JOIN guardian g ON sg.PARENT_ID = g.ID
        WHERE s.ID = ?
        LIMIT 1";



$stmt = $conn->prepare($sql);

// Bind parameter (s for string) to the prepared statement
$stmt->bind_param("s", $studentId);  // Bind the parameter as a string

// Execute the query
$stmt->execute();

// Get the result
$result = $stmt->get_result();



// Check if the query was successful and if there is at least one row
if ($result->num_rows > 0) {
    // Fetch the first (and only) row
    $firstRow = $result->fetch_assoc(); // Fetch the first row
 
} else {
    header("Location: index.php");
    // No data found
    echo json_encode(['message' => 'No students found']);
}


// SQL query to select one row from the student_qrcode table
$sqlqrcode = "SELECT * FROM student_qrcode WHERE STUDENT_NUMBER = ? LIMIT 1";

// Prepare the statement
$stmtqrcode = $conn->prepare($sqlqrcode);

// Bind parameter (i for integer)
$stmtqrcode->bind_param("i", $studentId);
// Execute the query
$stmtqrcode->execute();

// Get the result
$resultqrcode = $stmtqrcode->get_result();

// Fetch the row
$qrResultRow = $resultqrcode->fetch_assoc();
$qrImageB64 = '';
// Check if a row was found
if ($qrResultRow) {
    // Access the data from the row
    $qr_code = $qrResultRow['QR_CODE'];
    $qrImageB64 = getQRCodeImage($qrResultRow['QR_CODE']);
    $qrImageData = base64_decode($qrImageB64);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="view.css" rel="stylesheet"/>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css">
    <title>Edit Student</title>
</head>
<body>
    <?php include '../shared/sidebar.php' ?>
    <div class="container-main">
        <div class="main-wrapper-body card-container"> 
            <h3 class="fw-bold">Student Details</h3>
            <hr>
            <div class="row">
                <div class="col-lg-2 col-md-4 col-sm-12">
                    <img src="data:image/png;base64,<?=$firstRow['student_picture']?>" alt="" class="user-img" id="imgUser">
                    <br>
                    <br>
                    <?php if ($qrResultRow){ ?>
                        <img src="data:image/png;base64,<?=$qrImageB64?>" alt="QR Code" class="user-img" />
                        <a href="download-qr.php?qr_code=<?= urlencode($qr_code) ?>" class="btn btn-dark">Download QR Code</a>
                    <?php } ?>
                    <br><br>
                    <button class="btn btn-dark upload-btn" id="btnGenerateNewQR">Generate New QR</button><br><br>
                </div>
                <div class="col-lg-10 col-md-8 col-sm-12">
                    <!-- Student details -->
                    <div class="form-group">
                        <label for="txtFirstName">First Name</label>
                        <input type="text" class="form-control" id="txtFirstName" value="<?=$firstRow['student_first_name']?>" name="frmGroup" disabled>
                    </div>
                    <div class="form-group">
                        <label for="txtMiddleName">Middle Name</label>
                        <input type="text" class="form-control" id="txtMiddleName" value="<?=$firstRow['student_middle_name']?>" name="frmGroup" disabled>
                    </div>
                    <div class="form-group">
                        <label for="txtLastName">Last Name</label>
                        <input type="text" class="form-control" id="txtLastName" value="<?=$firstRow['student_last_name']?>" name="frmGroup" disabled>
                    </div>
                    <div class="form-group">
                        <label for="txtBirthDate">Date of Birth</label>
                        <input type="date" class="form-control" id="txtBirthDate" value="<?=$firstRow['student_birthdate']?>" name="frmGroup" disabled>
                    </div>
                    <script>
                        $(document).ready(function() {
                            $("#txtGradeLevel").val("<?=$firstRow['student_grade_level']?>").change();
                        });
                    </script>
                    <div class="form-group">
                        <label for="txtGradeLevel">Grade Level</label>
                        <select id="txtGradeLevel" class="form-control" name="frmGroup" disabled>
                            <option value="NURSERY">NURSERY</option>
                            <option value="KINDERGARTEN">KINDERGARTEN</option>
                            <option value="GRADE 1">GRADE 1</option>
                            <option value="GRADE 2">GRADE 2</option>
                            <option value="GRADE 3">GRADE 3</option>
                            <option value="GRADE 4">GRADE 4</option>
                            <option value="GRADE 5">GRADE 5</option>
                            <option value="GRADE 6">GRADE 6</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="txtSection">Section</label>
                        <input type="text" class="form-control" id="txtSection" value="<?=$firstRow['student_section']?>" name="frmGroup" disabled>
                    </div>
                    <div class="form-group">
                        <label for="txtAddress">Address</label>
                        <textarea id="txtAddress" class="form-control" rows="3" name="frmGroup" disabled><?=$firstRow['student_address']?></textarea>
                    </div>
                </div>
            </div>
        </div>
        <div class="main-wrapper-body card-container">
            <h3 class="fw-bold">Attendance</h3>
            <hr>
            <div class="table-container">
                <table class="table table-striped table-bordered" id="attendanceTable">
                    <thead class="table-dark">
                        <tr>
                            <th>Student #</th>
                            <th>Full Name</th>
                            <th>Grade Level</th>
                            <th>Section</th>
                            <th>Date</th>
                            <th>Time In</th>
                            <th>Time Out</th>
                            <th>Authorize Person</th>
                        </tr>
                    </thead>
                    <tbody id="body-table"></tbody>
                </table>
            </div>
        </div>
    </div>
</body>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
<script>
    $(document).ready(function() {
        // Initialize DataTable
        $('#attendanceTable').DataTable();

        // Disable input fields
        $("input[name='frmGroup'], select[name='frmGroup'], textarea[name='frmGroup']").attr("disabled", true);

        // Fetch data and populate the table
        fetchData();
    });

    $("#btnGenerateNewQR").on('click', function() {
        if (!confirm("Do you really want to generate new qrcode?")) {
            return;
        }

        $.ajax({
            url: 'generate-newqr-api.php',
            type: 'POST',
            data: {
                student_id: "<?=$firstRow['student_number']?>"
            },
            success: function(response) {
                if (response?.status === "success") {
                    alert(response?.message);
                    window.location.reload();
                }
            },
            error: function(xhr, status, error) {
                console.error("Error: " + error);
            }
        });
    });

    function fetchData() {
        var search = "<?=$studentId?>";

        // AJAX GET request
        $.ajax({
            url: 'search-attendance-api.php',
            method: 'GET',
            data: { search: search },
            success: function(response) {
                $("#body-table").html('');
                response?.forEach(function(item) {
                    $("#body-table").append(`
                        <tr>
                            <td>${item.student_number}</td>
                            <td>${item.student_name}</td>
                            <td>${item.grade_level}</td>
                            <td>${item.section}</td>
                            <td>${item.created_date}</td>
                            <td>${item.time_in}</td>
                            <td>${item.time_out}</td>
                            <td>${item.authorize_fullname}</td>
                        </tr>
                    `);
                });
            },
            error: function() {
                alert('An error occurred while fetching the data.');
            }
        });
    }
</script>
</html>
<?php
// Close the connection
$conn->close();
?>
