<?php
session_start();
include '../../Config/connection.php';
session_regenerate_id(true); // Prevent session fixation
$_SESSION['header'] = 'QR Scan Attendance';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="index.css" rel="stylesheet"/>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/html5-qrcode/minified/html5-qrcode.min.js"></script>
    <title>QR Code Attendance</title>
</head>
<body>
    <?php include '../shared/sidebar.php'; ?>
    <div class="container-main">
        <div class="main-wrapper-body">  
            <div class="row">
                <div class="col-lg-4 col-md-6 col-sm-12">
                    <div class="card card-container">
                        <div id="reader" style="width: 100%; height: 500px;"></div>
                    </div>
                </div>
                <div class="col-lg-8 col-md-6 col-sm-12" id="student-content" style="display: none;">
                    <div class="card card-container">
                        <div class="row">
                            <div class="col-4">
                                <img src="" alt="" class="user-img" id="imgUser">
                            </div>
                            <div class="col-8">
                                <div class="form-group">
                                    <label>Full Name</label>
                                    <input type="text" class="form-control" id="txtfullname" disabled>
                                </div>
                                <div class="form-group">
                                    <label>Grade</label>
                                    <input type="text" class="form-control" id="txtGrade" disabled>
                                </div>
                                <div class="form-group">
                                    <label>Section</label>
                                    <input type="text" class="form-control" id="txtSection" disabled>
                                </div>
                                <div class="form-group">
                                    <label>Date</label>
                                    <input type="date" class="form-control" id="txtBirthDate" disabled>
                                </div>
                                <h1 class="text-success"><b id="txtTimeAction"></b></h1>
                                <h4 id="authorizeTitle" style="display: none;">Select Authorized Person</h4>
                                <div class="row" id="authorizePersons"></div>
                                <button type="button" id="cancelButton" class="btn btn-danger" style="display: none;">Cancel</button>
                            </div> 
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script>
    let qrCodeScanner;
    let qrStatus = true;
    let scanCooldown = 30000; // 30 seconds cooldown

    $(document).ready(function () {
        reinitializeQRCode();
        
        $("#cancelButton").click(function () {
            clearStudentDetails();
            $("#student-content").hide();
            reinitializeQRCode();
        });
    });

    function onScanSuccess(decodedText) {
        if (isQRCodeInCooldown(decodedText)) {
            alert("QR Code is on cooldown. Please wait 30 seconds before scanning again.");
            return;
        }
        
        qrStatus = false;
        onQRScanAttendance(decodedText);
        setQRCodeCooldown(decodedText);
    }

    function reinitializeQRCode() {
        if (qrCodeScanner) {
            qrCodeScanner.clear().then(() => {
                console.log("QR Code scanner cleared successfully");
            }).catch(err => {
                console.error("Failed to clear QR Code scanner", err);
            });
        }
        
        qrCodeScanner = new Html5QrcodeScanner("reader", { fps: 5, qrbox: 300 }, false);
        qrCodeScanner.render(onScanSuccess, () => {});
    }

    function setQRCodeCooldown(qrCode) {
        sessionStorage.setItem(qrCode, Date.now());
        setTimeout(() => {
            sessionStorage.removeItem(qrCode);
        }, scanCooldown);
    }

    function isQRCodeInCooldown(qrCode) {
        let lastScanTime = sessionStorage.getItem(qrCode);
        if (!lastScanTime) return false;
        let elapsedTime = Date.now() - lastScanTime;
        return elapsedTime < scanCooldown;
    }

    function onQRScanAttendance(qrtext) {
        $.ajax({
            url: 'qr-attendance-api.php',
            type: 'POST',
            data: { qrcode_value: qrtext },
            dataType: 'json',
            success: function (response) {
                if (response.status === "cooldown") {
                    alert(response.message);
                    return;
                }

                $("#txtfullname").val(response.student_firstname + " " + response.student_lastname);
                $("#txtGrade").val(response.GRADE_LEVEL);
                $("#txtSection").val(response.SECTION);
                $("#txtBirthDate").val(response.CurrentDateNow);
                $("#imgUser").attr("src", "data:image/png;base64," + response.PICTURE);
                $("#txtTimeAction").text(response.action);

                if (response.action === "TIME OUT" || response.action === "ALREADY TIME OUT") {
                    displayAuthorizedPersons(response);
                    $("#authorizeTitle").show();
                    $("#cancelButton").show();
                } else {
                    $("#authorizeTitle, #authorizePersons, #cancelButton").hide();
                    setTimeout(() => {
                        clearStudentDetails();
                        $("#student-content").hide();
                        reinitializeQRCode();
                    }, 3000);
                }

                $("#student-content").show();
            },
            error: function (xhr, status, error) {
                console.error("Error:", error);
                alert("An error occurred while processing the request.");
                reinitializeQRCode();
            }
        });
    }

    function displayAuthorizedPersons(response) {
        $("#authorizePersons").html("");
        
        if (!response.authorizePersons || response.authorizePersons.length === 0) {
            $("#authorizePersons").html("<p>No authorized persons available.</p>");
        } else {
            response.authorizePersons.forEach(person => {
                $("#authorizePersons").append(`
                    <div class="col-lg-4 col-md-6 col-sm-12">
                        <div class="card-body">
                            <img src="data:image/png;base64,${person.PICTURE}" alt="" style="width: 100px; height: 100px; object-fit: cover; border-radius: 50%;"/>
                            <p>${person.first_name} ${person.last_name}</p>
                            <small>${person.role === 'guardian' ? 'Guardian' : 'Authorized Person'}</small>
                            <button onclick="authorizeTimeOut('${person.person_id}', '${response.attendance_id}', '${response.student_id}', '${response.student_firstname} ${response.student_lastname}', '${person.first_name} ${person.last_name}', '${response.PARENT_ID}')"
                                class="btn btn-primary">Select</button>
                        </div>
                    </div>
                `);
            });
        }
        $("#authorizeTitle, #authorizePersons").show();
    }
    function authorizeTimeOut(personId, attendanceId, studentId, studentName, authorizeName, parentId) {
    // Show loading state
    $("#authorizePersons").html("<p>Processing time out...</p>");
    
    $.ajax({
        url: 'select-person-api.php',
        type: 'POST',
        data: {
            authorize_id: personId,
            attendance_id: attendanceId,
            student_id: studentId,
            student_name: studentName,
            authorize_name: authorizeName,
            parent_id: parentId
        },
        dataType: 'json',
        success: function(response) {
            if (response.status === 'success') {
                // Success case
                Swal.fire({
                    icon: 'success',
                    title: 'Success',
                    text: response.message,
                    timer: 3000,
                    showConfirmButton: false
                });
                clearStudentDetails();
                $("#student-content").hide();
                reinitializeQRCode();
            } else {
                // Error case (including "already timed out")
                Swal.fire({
                    icon: 'info',
                    title: 'Notice',
                    text: response.message,
                    timer: 3000,
                    showConfirmButton: false
                });
                reinitializeQRCode();
            }
        },
        error: function(xhr, status, error) {
            // Handle AJAX errors
            let errorMessage = "An error occurred while processing the request.";
            try {
                const jsonResponse = JSON.parse(xhr.responseText);
                errorMessage = jsonResponse.message || errorMessage;
            } catch (e) {
                console.error("Error parsing response:", e);
            }
            
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: errorMessage,
                timer: 3000,
                showConfirmButton: false
            });
            reinitializeQRCode();
        }
    });
}

    function clearStudentDetails() {
        $("#txtfullname, #txtGrade, #txtSection, #txtBirthDate").val('');
        $("#imgUser").attr("src", '');
        $("#txtTimeAction").text('');
        $("#authorizePersons").html('');
    }
    </script>
</body>
</html>