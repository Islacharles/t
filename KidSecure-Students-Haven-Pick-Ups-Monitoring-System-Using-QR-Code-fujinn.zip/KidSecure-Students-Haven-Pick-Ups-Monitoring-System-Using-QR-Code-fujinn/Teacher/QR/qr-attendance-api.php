<?php
date_default_timezone_set('Asia/Manila');
include '../../Config/api-config.php';
include '../../Config/connection.php';
session_start();

// Ensure request is POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['status' => 'error', 'message' => 'Invalid request method.']);
    exit();
}

// Collect input values
$qrcode_value = $_POST['qrcode_value'] ?? null;

$conn->query("SET time_zone = '+08:00'");

// Apply 30s delay on first scan
if ($qrcode_value) {
    if (!isset($_SESSION['scan_times'])) {
        $_SESSION['scan_times'] = [];
    }

    if (isset($_SESSION['scan_times'][$qrcode_value])) {
        $lastScan = $_SESSION['scan_times'][$qrcode_value];
        $elapsed = time() - $lastScan;
        if ($elapsed < 30) {
            echo json_encode(['status' => 'cooldown', 'message' => 'Please wait 30 seconds before scanning again.']);
            exit();
        }
    }

    $_SESSION['scan_times'][$qrcode_value] = time();
}

// Fetch student info
$sql = "SELECT 
            s.ID AS student_id,
            s.FIRSTNAME AS student_firstname,
            s.LASTNAME AS student_lastname,
            s.GRADE_LEVEL,
            s.SECTION,
            s.PICTURE,
            sq.QR_CODE,
            CURRENT_DATE() as CurrentDateNow,
            sg.PARENT_ID
        FROM 
            students s
        INNER JOIN 
            student_qrcode sq ON s.ID = sq.STUDENT_NUMBER
        LEFT JOIN
            student_guardian sg ON sg.STUDENT_NUMBER = s.ID
        WHERE 
            sq.QR_CODE = ? 
        LIMIT 1";

$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $qrcode_value);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $students = $row;
    $studentId = $row['student_id'];

    // Check attendance for today
    $sqlCheckAttendance = "SELECT * FROM student_attendance 
                           WHERE STUDENT_ID = ? 
                           AND CREATED_DT = CURRENT_DATE() 
                           ORDER BY TIME_IN DESC 
                           LIMIT 1";
    $stmtCheckAttendance = $conn->prepare($sqlCheckAttendance);
    $stmtCheckAttendance->bind_param("s", $studentId);
    $stmtCheckAttendance->execute();
    $resultCheckAttendance = $stmtCheckAttendance->get_result();

    if ($resultCheckAttendance->num_rows > 0) {
        $rowAttendance = $resultCheckAttendance->fetch_assoc();
        $students['attendance'] = $rowAttendance;
        $students['attendance_id'] = $rowAttendance['ID'];

        if (!is_null($rowAttendance['TIME_OUT'])) {
            $students['action'] = "ALREADY TIME OUT";
        } else {
            $students['action'] = "TIME OUT";
        }
    } else {
        // Insert TIME_IN if no record exists today
        $sqlInsert = "INSERT INTO student_attendance (STUDENT_ID, CREATED_DT, TIME_IN) VALUES (?, CURRENT_DATE(), NOW())";
        $stmtInsert = $conn->prepare($sqlInsert);
        $stmtInsert->bind_param("s", $studentId);
        $stmtInsert->execute();
        $insertId = $stmtInsert->insert_id;
        $stmtInsert->close();
        
        $students['action'] = "TIME IN";
        $students['attendance_id'] = $insertId;
    }

    $stmtCheckAttendance->close();
}

// Fetch authorized persons (guardians and authorized persons)
$sqlAuthorize = "SELECT 
        g.ID AS person_id,
        g.FIRSTNAME AS first_name,
        g.LASTNAME AS last_name,
        g.CONTACT_NUMBER AS contact_number,
        g.ADDRESS AS address,
        g.EMAIL AS email,
        'guardian' AS role,
        g.PICTURE
    FROM 
        guardian g
    INNER JOIN 
        student_guardian sg ON g.ID = sg.PARENT_ID
    WHERE 
        sg.STUDENT_NUMBER = ?
    UNION
    SELECT 
        ap.ID AS person_id,
        ap.FIRSTNAME AS first_name,
        ap.LASTNAME AS last_name,
        ap.CONTACT_NUMBER AS contact_number,
        ap.ADDRESS AS address,
        NULL AS email,
        'authorize_person' AS role,
        ap.PICTURE
    FROM 
        authorize_person ap
    INNER JOIN
        student_guardian sg ON ap.PARENT_ID = sg.PARENT_ID
    WHERE 
        sg.STUDENT_NUMBER = ?";

$stmtAuthorize = $conn->prepare($sqlAuthorize);
$stmtAuthorize->bind_param("ii", $studentId, $studentId);
$stmtAuthorize->execute();
$resultAuthorize = $stmtAuthorize->get_result();

$authorizePersons = [];
while ($rowAuthorize = $resultAuthorize->fetch_assoc()) {
    $authorizePersons[] = $rowAuthorize;
}

$students['authorizePersons'] = $authorizePersons;

$stmt->close();
$stmtAuthorize->close();
$conn->close();

header('Content-Type: application/json');
echo json_encode($students);
?>