<?php
date_default_timezone_set('Asia/Manila');
header('Content-Type: application/json');

include '../../Config/connection.php';
include '../../Config/notification-api.php';

try {
    // Check if the request method is POST
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception('Invalid request method', 405);
    }

    // Collect and validate POST data
    $requiredFields = ['attendance_id', 'authorize_id', 'student_id'];
    foreach ($requiredFields as $field) {
        if (empty($_POST[$field])) {
            throw new Exception("Required information is missing", 400);
        }
    }

    $attendanceId = $_POST['attendance_id'];
    $authorizeId = $_POST['authorize_id'];
    $studentId = $_POST['student_id'];
    $studentName = $_POST['student_name'] ?? 'Student';
    $authorizeName = $_POST['authorize_name'] ?? 'Authorized Person';
    $parentId = $_POST['parent_id'] ?? null;

    // Check if already timed out
    $checkSql = "SELECT TIME_OUT FROM student_attendance WHERE ID = ? AND STUDENT_ID = ?";
    $checkStmt = $conn->prepare($checkSql);
    $checkStmt->bind_param("ss", $attendanceId, $studentId);
    $checkStmt->execute();
    $result = $checkStmt->get_result();
    
    if ($result->num_rows === 0) {
        throw new Exception("Attendance record not found", 404);
    }
    
    $row = $result->fetch_assoc();
    if ($row['TIME_OUT'] !== null) {
        // Return a user-friendly message for already timed out
        echo json_encode([
            'status' => 'info',
            'message' => 'This student has already been signed out today.'
        ]);
        exit();
    }

    // Update attendance record
    $updateSql = "UPDATE student_attendance 
                 SET AUTHORIZE_ID = ?, TIME_OUT = NOW() 
                 WHERE ID = ? AND STUDENT_ID = ? AND TIME_OUT IS NULL";
    $updateStmt = $conn->prepare($updateSql);
    $updateStmt->bind_param("sss", $authorizeId, $attendanceId, $studentId);

    if (!$updateStmt->execute()) {
        throw new Exception("Failed to update attendance record", 500);
    }

    // Send notification if parent exists
    if ($parentId) {
        $title = 'Attendance';
        $redirection = '../student/view.php?id=' . $studentId;
        $description = "$studentName has been signed out by $authorizeName";
        
        $notifSql = "INSERT INTO notifications (USER_ID, TITLE, REDIRECTION, DESCRIPTION, STUDENT_ID) 
                     VALUES (?, ?, ?, ?, ?)";
        $notifStmt = $conn->prepare($notifSql);
        $notifStmt->bind_param("issss", $parentId, $title, $redirection, $description, $studentId);
        
        if (!$notifStmt->execute()) {
            error_log("Failed to send notification: " . $conn->error);
        }
        $notifStmt->close();
    }

    echo json_encode([
        'status' => 'success',
        'message' => 'Student successfully signed out with ' . $authorizeName
    ]);

} catch (Exception $e) {
    http_response_code($e->getCode() ?: 500);
    echo json_encode([
        'status' => 'error',
        'message' => $e->getMessage()
    ]);
} finally {
    if (isset($conn)) $conn->close();
}
?>