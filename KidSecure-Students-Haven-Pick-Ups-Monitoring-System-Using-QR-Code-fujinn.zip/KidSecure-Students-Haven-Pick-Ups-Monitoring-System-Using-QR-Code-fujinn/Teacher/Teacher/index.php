<?php
header("Location: attendance/");
?>