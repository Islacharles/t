<?php 
session_start();
include '../../Config/connection.php'; 
$_SESSION['header'] = 'Announcements';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Announcements</title>

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="index.css" rel="stylesheet" />

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <style>
        .announcement-card {
            border-radius: 10px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
            padding: 15px;
            background-color: #fff;
            margin-bottom: 20px;
            transition: transform 0.2s ease-in-out;
        }

        .announcement-card:hover {
            transform: translateY(-5px);
        }

        .admin-img {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            object-fit: cover;
        }

        .announcement-title {
            font-size: 1.2rem;
            font-weight: bold;
        }

        .announcement-description {
            font-size: 0.95rem;
            color: #555;
        }
    </style>
</head>

<body>

<?php include '../shared/sidebar.php'; ?>

<div class="container mt-4">
    <h2 class="mb-3 text-center">📢 Announcements</h2>

    <div class="row">
        <?php
        $sql = "SELECT a.title, a.description, a.created_at, u.fullname AS admin_name, u.profile_image 
                FROM announcements a 
                JOIN admin_staff u ON a.added_by = u.id 
                ORDER BY a.id DESC";

        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $profilePicture = !empty($row['profile_image']) ? '../../uploads/' . $row['profile_image'] : '../../assets/logo.png';

                echo "
                <div class='col-md-6 col-lg-4'>
                    <div class='announcement-card'>
                        <div class='d-flex align-items-center mb-2'>
                            <img src='{$profilePicture}' class='admin-img me-2' alt='Admin Profile'>
                            <div>
                                <div class='fw-bold'>{$row['admin_name']}</div>
                                <small class='text-muted'>" . date("F j, Y, g:i A", strtotime($row['created_at'])) . "</small>
                            </div>
                        </div>
                        <div class='announcement-title'>{$row['title']}</div>
                        <div class='announcement-description'>{$row['description']}</div>
                    </div>
                </div>";
            }
        } else {
            echo "<p class='text-center'>No Announcements Found</p>";
        }
        ?>
    </div>
</div>

</body>
</html>
