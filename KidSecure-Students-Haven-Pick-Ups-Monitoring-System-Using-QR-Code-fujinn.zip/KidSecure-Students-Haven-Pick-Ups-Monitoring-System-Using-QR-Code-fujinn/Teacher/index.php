<?php
header("Location: attendance/");
?>