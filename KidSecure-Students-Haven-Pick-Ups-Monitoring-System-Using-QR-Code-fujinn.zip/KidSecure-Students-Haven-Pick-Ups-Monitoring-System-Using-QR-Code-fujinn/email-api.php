<?php
date_default_timezone_set('Asia/Manila');
include 'Config/connection.php'; // Include the database connection

// Get the email from the form
$email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);

if (!$email) {
    die("Invalid email provided.");
}

try {
    // Query to check if the email exists in the `guardian`, `teacher`
    $stmt = $conn->prepare("
        SELECT 'guardian' AS table_name, ID, FIRSTNAME, MIDDLENAME, LASTNAME, EMAIL 
        FROM guardian 
        WHERE EMAIL = ?
        UNION 
        SELECT 'teacher' AS table_name, ID, FIRSTNAME, MIDDLENAME, LASTNAME, EMAIL 
        FROM teachers 
        WHERE EMAIL = ?
    ");
    $stmt->bind_param("ss",  $email, $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 0) {
        $error = "Email not found in our records.";
        include 'forgotPassword.php'; 
        exit;
    }

    // Fetch user data if email exists
    $user = $result->fetch_assoc();
    $userId = $user['ID'];
    $recipientEmail = $user['EMAIL'];
    $recipientName = $user['FIRSTNAME'] . " " . $user['MIDDLENAME'] . " " . $user['LASTNAME'];

    // Generate a unique token and expiration time
    $token = bin2hex(random_bytes(16)); // Generate a 32-character token
    $expiration = date('Y-m-d H:i:s', strtotime('+1 hour')); // Token valid for 1 hour

    // Insert the token and expiration into the forgot_password table
    $insertStmt = $conn->prepare("
        INSERT INTO forgot_password (USER_ID, TOKEN, EXPIRATION)
        VALUES (?, ?, ?)
        ON DUPLICATE KEY UPDATE TOKEN = VALUES(TOKEN), EXPIRATION = VALUES(EXPIRATION)
    ");
    $insertStmt->bind_param("iss", $userId, $token, $expiration);
    $insertStmt->execute();

    if ($insertStmt->affected_rows === 0) {
        die("Failed to generate reset link. Please try again later.");
    }

    // Send email with reset link
    $url = "https://api.mailersend.com/v1/email";
    $apiKey = "mlsn.0c6e50b3b774ef8f9e08f9111d44e9b0d94cfcefecb089c24d20c611f508303c"; // Replace with your actual API token

    $data = [
        "from" => [
            "email" => "support@kidsec.online" // Sender's email
        ],
        "to" => [
            [
                "email" => $recipientEmail // Dynamically fetched email
            ]
        ],
        "subject" => "Password Recovery Request",
        "personalization" => [
            [
                "email" => $recipientEmail,
                "data" => [
                    "name" => $recipientName,
                    "reset_link" =>  $token, // Add reset link to email
                    "support_email" => "support@kidsec.online"
                    
                ]
            ]
        ],
        "template_id" => "3z0vklopno7g7qrx" // Your email template ID
    ];

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "Authorization: Bearer $apiKey",
        "Content-Type: application/json",
        "X-Requested-With: XMLHttpRequest"
    ]);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));

    $response = curl_exec($ch);

    if (curl_errno($ch)) {
        echo "Error: " . curl_error($ch);
    } else {
        echo "Password recovery email sent successfully to " . $recipientEmail;
    }
    
    curl_close($ch);
} catch (Exception $e) {
    die("Error: " . $e->getMessage());
}
?>
