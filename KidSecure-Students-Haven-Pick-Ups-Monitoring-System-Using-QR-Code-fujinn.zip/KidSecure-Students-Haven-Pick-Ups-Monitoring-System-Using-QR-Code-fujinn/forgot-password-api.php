<?php
session_start();
include 'Config/connection.php'; 
include 'Config/encryption.php'; 

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $newPassword = $_POST['new_password'];
    $confirmPassword = $_POST['confirm_password'];
    $token = $_GET['token'] ?? '';

    // Validate the inputs
    if (empty($newPassword) || empty($confirmPassword)) {
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => 'Both password fields are required.']);
        exit;
    }

    if ($newPassword !== $confirmPassword) {
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => 'Passwords do not match.']);
        exit;
    }

    // Check if the token exists and retrieve user info
    $stmt = $conn->prepare("
        SELECT USER_ID, EXPIRATION
        FROM forgot_password
        WHERE TOKEN = ?
    ");
    $stmt->bind_param("s", $token);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows === 0) {
        http_response_code(404);
        echo json_encode(['status' => 'error', 'message' => 'Invalid or expired token.']);
        exit;
    }

    $stmt->bind_result($userId, $expiration);
    $stmt->fetch();
    $stmt->close();

    // Check if the token has expired
    $currentDateTime = new DateTime();
    $expirationDateTime = new DateTime($expiration);

    if ($currentDateTime >= $expirationDateTime) {
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => 'Token has expired.']);
        exit;
    }

    // Hash the new password
    $hashedPassword = encrypt($newPassword);

    // Check if USER_ID exists in `guardian` or `teachers` table
    $guardianStmt = $conn->prepare("SELECT ID FROM guardian WHERE ID = ?");
    $guardianStmt->bind_param("i", $userId);
    $guardianStmt->execute();
    $guardianStmt->store_result();

    if ($guardianStmt->num_rows > 0) {
        // Update password in `guardian` table
        $updateStmt = $conn->prepare("
            UPDATE guardian
            SET PASSWORD = ?
            WHERE ID = ?
        ");
        $updateStmt->bind_param("si", $hashedPassword, $userId);
    } else {
        // Check `teachers` table
        $teacherStmt = $conn->prepare("SELECT ID FROM teachers WHERE ID = ?");
        $teacherStmt->bind_param("i", $userId);
        $teacherStmt->execute();
        $teacherStmt->store_result();

        if ($teacherStmt->num_rows > 0) {
            // Update password in `teachers` table
            $updateStmt = $conn->prepare("
                UPDATE teachers
                SET PASSWORD = ?
                WHERE ID = ?
            ");
            $updateStmt->bind_param("si", $hashedPassword, $userId);
        } else {
            http_response_code(404);
            echo json_encode(['status' => 'error', 'message' => 'User not found in guardian or teachers table.']);
            exit;
        }

        $teacherStmt->close();
    }

    $guardianStmt->close();
    $updateStmt->execute();

    if ($updateStmt->affected_rows > 0) {
        // Optionally delete the token after successful reset
        $deleteTokenStmt = $conn->prepare("DELETE FROM forgot_password WHERE TOKEN = ?");
        $deleteTokenStmt->bind_param("s", $token);
        $deleteTokenStmt->execute();

        echo json_encode(['status' => 'success', 'message' => 'Password updated successfully.']);
    } else {
        http_response_code(500);
        echo json_encode(['status' => 'error', 'message' => 'Failed to update password.']);
    }

    $updateStmt->close();
    $deleteTokenStmt->close();
} else {
    http_response_code(405);
    echo json_encode(['status' => 'error', 'message' => 'Invalid request method.']);
    exit;
}
?>
