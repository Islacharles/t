<?php
include 'Config/connection.php'; 
include 'Config/encryption.php'; 
if (!isset($_GET['token'])) {
    header("Location: index.php");
    exit;
}

$token = $_GET['token'];

// Check if the token exists and retrieve user information
$stmt = $conn->prepare("
    SELECT fp.USER_ID, fp.EXPIRATION, g.ID AS guardian_id, t.ID AS teacher_id
    FROM forgot_password fp
    LEFT JOIN guardian g ON fp.USER_ID = g.ID
    LEFT JOIN teachers t ON fp.USER_ID = t.ID
    WHERE fp.TOKEN = ?
");
$stmt->bind_param("s", $token);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows > 0) {
    $stmt->bind_result($userId, $expiration, $guardianId, $teacherId);
    $stmt->fetch();

    // Check if the token has expired
    $currentDateTime = new DateTime();
    $expirationDateTime = new DateTime($expiration);

    if ($currentDateTime >= $expirationDateTime) {
        header("Location: index.php");
        exit;
    }
} else {
    header("Location: index.php");
    exit;
}

$stmt->close();

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<?php include 'Config/jslib.php'; ?>

<style>
    /* Global Reset */
    body, html {
        margin: 0;
        padding: 0;
        height: 100%;
        font-family: Arial, sans-serif;
    }

    /* Background Image */
    body {
        background-image: url('assets/aa.jpg'); /* Use the image as the background */
        background-size: cover; /* Ensure the image covers the entire screen */
        background-position: center; /* Center the image */
        background-repeat: no-repeat;
    }

    /* Centered Login Container */
    .login-container {
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        width: 100%;
        max-width: 400px;
        padding: 20px;
        background-color: rgba(255, 255, 255, 0.85); /* Semi-transparent background */
        border-radius: 20px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        text-align: center;
    }

    .login-container img {
        max-width: 120px;
        height: auto;
        margin-bottom: 20px;
    }

    .login-container h2 {
        margin-bottom: 20px;
        font-size: 24px;
        font-weight: bold;
        color: #333;
    }

    .login-container label {
        display: block;
        margin-bottom: 5px;
        color: #666;
        text-align: left;
        font-size: 14px;
    }

    .login-container input[type="email"],
    .login-container input[type="password"] {
        width: 100%;
        padding: 12px;
        margin-bottom: 15px;
        border: 1px solid #ddd;
        border-radius: 5px;
        background-color: #f9f9f9;
        font-size: 14px;
    }

    .login-container button {
        width: 100%;
        padding: 12px;
        border: none;
        border-radius: 5px;
        background: linear-gradient(90deg, #6a11cb, #2575fc);
        color: white;
        font-size: 16px;
        cursor: pointer;
        transition: background 0.3s ease;
    }

    .login-container button:hover {
        background: linear-gradient(90deg, #2575fc, #6a11cb);
    }

    .login-container a {
        color: #6a11cb;
        text-decoration: none;
        font-size: 14px;
        display: block;
        margin-top: 10px;
    }

    .login-container a:hover {
        text-decoration: underline;
    }

    .error {
        background-color: #f8d7da;
        color: #721c24;
        padding: 10px;
        border: 1px solid #f5c6cb;
        border-radius: 5px;
        margin-bottom: 15px;
    }

    /* Responsive Design */
    @media (max-width: 480px) {
        .login-container h2 {
            font-size: 20px;
        }

        .login-container button {
            font-size: 14px;
        }

        .login-container input[type="email"],
        .login-container input[type="password"] {
            font-size: 12px;
            padding: 10px;
        }
    }
</style>
    <div class="container d-flex justify-content-center align-items-center vh-100">
        <div class="card shadow-lg p-4" style="width: 100%; max-width: 400px;">
            <h3 class="text-center mb-4">Reset Password</h3>
                <div class="mb-3">
                    <label for="new-password" class="form-label">New Password</label>
                    <input type="password" class="form-control" id="new_password" placeholder="Enter new password" required>
                </div>
                <div class="mb-3">
                    <label for="confirm-password" class="form-label">Confirm Password</label>
                    <input type="password" class="form-control" id="confirm_password" placeholder="Confirm new password" required>
                </div>
                <button type="button" id="resetpass" class="btn btn-primary w-100">Reset Password</button>
                <div class="mt-3 text-center">
                    <a href="index.php">Back to Login</a>
                </div>
        </div>
    </div>
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
         $('#resetpass').click(function () {
    let result = confirm("Do you want to continue?");
    if (result) {
        let newPassword = $('#new_password').val();
        let confirmPassword = $('#confirm_password').val();

        if (newPassword === confirmPassword) {
            $.ajax({
                url: 'forgot-password-api.php?token=<?=$_GET['token']?>',
                method: 'POST',
                data: {
                    'new_password': newPassword, // Match this key to PHP
                    'confirm_password': confirmPassword, // Match this key to PHP
                },
                success: function (response) {
                    alert('Password updated successfully!');
                },
                error: function () {
                    alert('Error updating password. Please try again.');
                }
            });
        } else {
            alert("Passwords do not match! Please try again.");
        }
    } else {
        console.log("User clicked Cancel");
    }
});
    </script>
</body>
</html>
