<?php
// Unset all session variables
session_start();
$_SESSION = [];
    session_destroy();
    header("Location: Index.php");
?>
