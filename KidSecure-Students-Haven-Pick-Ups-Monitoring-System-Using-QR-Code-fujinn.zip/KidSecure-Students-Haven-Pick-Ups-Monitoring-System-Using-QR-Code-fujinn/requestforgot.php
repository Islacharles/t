<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<?php include 'Config/jslib.php'; ?>

<style>

    body, html {
        margin: 0;
        padding: 0;
        height: 100%;
        font-family: Arial, sans-serif;
    }

    /* Background Image */
    body {
        background-image: url('assets/aa.jpg'); /* Use the image as the background */
        background-size: cover; /* Ensure the image covers the entire screen */
        background-position: center; /* Center the image */
        background-repeat: no-repeat;
    }

    /* Centered Login Container */
    .login-container {
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        width: 100%;
        max-width: 400px;
        padding: 20px;
        background-color: rgba(255, 255, 255, 0.85); /* Semi-transparent background */
        border-radius: 20px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        text-align: center;
    }

    .login-container img {
        max-width: 120px;
        height: auto;
        margin-bottom: 20px;
    }

    .login-container h2 {
        margin-bottom: 20px;
        font-size: 24px;
        font-weight: bold;
        color: #333;
    }

    .login-container label {
        display: block;
        margin-bottom: 5px;
        color: #666;
        text-align: left;
        font-size: 14px;
    }

    .login-container input[type="email"],
    .login-container input[type="password"] {
        width: 100%;
        padding: 12px;
        margin-bottom: 15px;
        border: 1px solid #ddd;
        border-radius: 5px;
        background-color: #f9f9f9;
        font-size: 14px;
    }

    .login-container button {
        width: 100%;
        padding: 12px;
        border: none;
        border-radius: 5px;
        background: linear-gradient(90deg, #6a11cb, #2575fc);
        color: white;
        font-size: 16px;
        cursor: pointer;
        transition: background 0.3s ease;
    }

    .login-container button:hover {
        background: linear-gradient(90deg, #2575fc, #6a11cb);
    }

    .login-container a {
        color: #6a11cb;
        text-decoration: none;
        font-size: 14px;
        display: block;
        margin-top: 10px;
    }

    .login-container a:hover {
        text-decoration: underline;
    }

    .error {
        background-color: #f8d7da;
        color: #721c24;
        padding: 10px;
        border: 1px solid #f5c6cb;
        border-radius: 5px;
        margin-bottom: 15px;
    }

    /* Responsive Design */
    @media (max-width: 480px) {
        .login-container h2 {
            font-size: 20px;
        }

        .login-container button {
            font-size: 14px;
        }

        .login-container input[type="email"],
        .login-container input[type="password"] {
            font-size: 12px;
            padding: 10px;
        }
    }
</style>
</head>
<body>

    <div class="login-container">
        <h2>Forgot Password</h2>

         <?php if (isset($error)): ?>
            <div class="error"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <?php if (isset($success)): ?>
            <div class="success"><?php echo htmlspecialchars($success); ?></div>
        <?php endif; ?>

        <!-- Login form -->
        <form id="resetForm" method="POST" action="email-api.php">
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" name="email" id="email" required>
            </div>
            <button type="submit" class="btn">Send</button>
            <div class="mt-3 text-center">
                    <a href="index.php">Back to Login</a>
                </div>
        </form>
    </div>
    <div class="modal fade" id="successModal" tabindex="-1" aria-labelledby="successModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="successModalLabel">Success</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                Password recovery email has been sent successfully to your email.
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary" data-bs-dismiss="modal">OK</button>
            </div>
        </div>
    </div>
</div>

<script>
    // Handle form submission
    document.getElementById('resetForm').addEventListener('submit', function (e) {
        e.preventDefault(); // Prevent default form submission

        // Simulate API call
        const formData = new FormData(this);
        fetch('email-api.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.text()) // Process response from the server
        .then(data => {
            // Assuming the server indicates success
            if (data.trim().toLowerCase().includes('success')) {
    const successModal = new bootstrap.Modal(document.getElementById('successModal'));
    successModal.show();
} else {
    alert('Failed to send email. Please try again.');
}

        })
        .catch(error => {
            console.error('Error:', error);
        });
    });
</script>
</body>
</html>
